const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function formatTimeTwo(str) { //获取时间拼接为2018-08-01格式
  var oDate = new Date(str),
    oYear=oDate.getFullYear(),
    oMonth = oDate.getMonth() + 1,
    oDay = oDate.getDate()
    if(oMonth<10){
      oMonth='0'+oMonth
    }
    if (oDay < 10) {
      oDay = '0' + oDay
    }
   var oTime = oYear +'-'+ oMonth + '-' + oDay;//最后拼接时间  
  return oTime;
};
function formatTimeThree(str) { //获取时间拼接为15：02格式
  var oDate = new Date(str),
    oHour = oDate.getHours(),
    oMinute=oDate.getMinutes()
  if (oHour < 10) {
    oHour = '0' + oHour
  }
  if (oMinute < 10) {
    oMinute = '0' + oMinute
  }
  var Time = oHour + ':' + oMinute;//最后拼接时间  
  return Time;
};

function SecondToDate(time) { //获取时间拼接为15：02：34格式

  if (null != time && ""!= time) {
  
    if (time > 60 && time < 60 * 60) {
      var min = parseInt(time / 60.0) 
      // var second = parseInt((parseFloat(time / 60.0) -
      //   parseInt(time / 60.0)) * 60)
      var second = parseInt(time - parseInt(time / 60.0)*60)
      if(min<10){
        min='0'+min
      }
      if(second<10){
        second='0'+second
      }
      time ='00:'+ min+ ":" + second ;
    }
    else if (time >= 60 * 60 && time < 60 * 60 * 24) {
      var hour = parseInt(time / 3600.0);
      var min = parseInt((parseFloat(time / 3600.0) -parseInt(time / 3600.0)) * 60);
      var second = parseInt((parseFloat((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60) -
        parseInt((parseFloat(time / 3600.0) - parseInt(time / 3600.0)) * 60)) * 60) ;
        if(hour<10){
          hour='0'+hour;
        }
        if (min < 10) {
          min = '0' + min
        }
        if (second < 10) {
          second = '0' + second
        }
      time = hour+ ":" + min+ ":" +second ;
    }
    else {
      var second = parseInt(time);
      if (second < 10) {
        second = '0' + second
      }
      time = '00:00:' + second;
    }
  }
  return time;
}

 function Max(arr) {
  return Math.max.apply(Math, arr);
} 

 function ScreenDate(abc) {  //筛选数据，将同一天的数据放在一个数组中
   var arr = {};
   for (var i = 0, idx = abc.length; i < idx; i++) {
     if (!arr[abc[i].fitnesstime]) {
       arr[abc[i].fitnesstime] = [];
       arr[abc[i].fitnesstime].push(abc[i])
     } else {
       arr[abc[i].fitnesstime].push(abc[i])
     }
   }
   return arr;
 }
 function Week(i) { //获取一周的日期拼接为2018-08-03格式
   var now = new Date();
   var firstDay = new Date(now - (now.getDay() - 1) * 86400000);
   firstDay.setDate(firstDay.getDate() + i);
   var year=firstDay.getFullYear();
   var mon = Number(firstDay.getMonth()) + 1;
   var day = firstDay.getDate();
   if (day < 10) {
     day = "0" + day
   }
   if (mon < 10) {
     mon = '0' + mon
   }
   return year+'-'+ mon + "-" + day;
 }
 function trans(arr) { 
   let obj = {}
   let result = []
   arr.forEach(({ fitnesstime, exercisetime}) => {
     let cur = obj[fitnesstime]
     if (cur) {
       let index = cur.index
       result[index].exercisetime += exercisetime
     } else {
       let index = result.length
       obj[fitnesstime] = {
         fitnesstime,
         index
       }
       result.push({ fitnesstime, exercisetime })
     }
   })
   return result
 }

function RunningScreenDate(abc) {  //筛选数据，将同一天的数据放在一个数组中
  var arr = {};
  for (var i = 0, idx = abc.length; i < idx; i++) {
    if (!arr[abc[i].recreatetime]) {
      arr[abc[i].recreatetime] = [];
      arr[abc[i].recreatetime].push(abc[i])
    } else {
      arr[abc[i].recreatetime].push(abc[i])
    }
  }
  return arr;
}
function runningtrans(arr){
  let obj = {}
  let result = []
  arr.forEach(({ recreatetime, reduration }) => {
    let cur = obj[recreatetime]
    if (cur) {
      let index = cur.index
      result[index].reduration += reduration
    } else {
      let index = result.length
      obj[recreatetime] = {
        recreatetime,
        index
      }
      result.push({ recreatetime, reduration })
    }
  })
  return result
}
module.exports = {
  formatTime: formatTime, 
  formatTimeTwo: formatTimeTwo,
  formatTimeThree: formatTimeThree,
 
  SecondToDate: SecondToDate,
  Max:Max,
  ScreenDate:ScreenDate,
  Week: Week,
  RunningScreenDate: RunningScreenDate,
  trans: trans,
  runningtrans: runningtrans
}
