// pages/fitness/fitnesshomepage/fitnesshomepage.js
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items:[{
      src:"../../image/1.jpg"
    },{
      src:'../../image/2.jpg'
    },{
      src:'../../image/3.jpg'
    }],
    num: '2',
    calories: '123',
     time: '10'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.openBluetoothAdapter({
      success: function (res) {
        console.log(res)
        console.log("蓝牙已打开")
      },
      fail:function(){
        console.log("蓝牙未打开");
            wx.showModal({
        title: '蓝牙未打开',
        content: '请前往设置中心开启蓝牙',
        success: function (res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
      }
    });
    console.log(app.globalData.Url)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Fitnesscenter:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesscenter/fitnesscenter',
    })
  },
  Fitnesshistory:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesshistory/fitnesshistory',
    })
  },
  Fitnessrankings: function () {
    wx.navigateTo({
      url: '../../fitness/fitnessrankings/fitnessrankings',
    })
  },
  // Fitnessbluetooth: function () {

  
  //     wx.showModal({
  //       title: '蓝牙未打开',
  //       content: '立即前往设置中心开启蓝牙',
  //       success: function (res) {
  //         if (res.confirm) {
  //           console.log('用户点击确定')
  //         } else if (res.cancel) {
  //           console.log('用户点击取消')
  //         }
  //       }
  //     })
     

   
  // },
  Fitnessscan: function () {
    wx.navigateTo({
      url: '../../fitness/fitnessscan/fitnessscan',
    })
  }
  
})