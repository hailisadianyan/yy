// pages/fitness/fitnesshomepage/fitnesshomepage.js
const app=getApp();
var util = require('../../../utils/util.js'); 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items:[],
    num: '',
    calories: '',
     time: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;    
    // wx.showLoading({
    //   title: '加载中...',
    //   mask:true,
    //   success:function(){
    //     
    //   }
    // })
    // setTimeout(function () {
    //   wx.hideLoading()
    // }, 2000)
   
    that.getBluetoothstatus();
    
    that.GetSwiperImage();//获取轮播图片的函数
    that.Getfitnesstime();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Fitnesscenter:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesscenter/fitnesscenter',
    })
  },
  Fitnesshistory:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesshistory/fitnesshistory',
    })
  },
  Fitnessrankings: function () {
    wx.navigateTo({
      url: '../../fitness/fitnessrankings/fitnessrankings',
    })
  },

  Fitnessscan: function () {
    wx.navigateTo({
      url: '../../fitness/fitnessscan/fitnessscan',
    })
  },
  GetSwiperImage:function(){
    var that=this;
    wx.request({ //获取轮播图片
      url: 'https://www.sjxty.net/OutdoorFitness/app/user/getPictureCarouselCustom', //接口地址
      data: {  //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json'
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data.data.carouselImgs)
        var a = [];
        for (var i = 0; i < res.data.data.carouselImgs.length; i++) {

          a.push({ src: "https://www.sjxty.net/image" + res.data.data.carouselImgs[i].pciimg });
        }
        console.log(a);
        that.setData({
          items: a
        })
      }
    })
  },
  Getfitnesstime:function(){
    var that = this;
    var time = util.formatTime(new Date());  
    wx.request({ //获取总健身记录
      url: app.globalData.Url +'/OutdoorFitness/app/user/fitness/getTimesTotalRecords', //接口地址
      data: {  //参数为json格式数据
        dayType:4,
        frcreatetime:time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token'),
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        if(res.data.code==1000){
        if(res.data.data){
        that.setData({
          num: res.data.data.times,
          calories: res.data.data.consume,
          time:Math.ceil(res.data.data.duration/60)
        })
        }else{
          that.setData({
            num: 0,
            calories:0,
            time: 0
          }) 
        }
       }
  
      if(res.data.code==1001){
        wx.redirectTo({
          url: '../../loginregister/login/login',
        })
      }
      }
    })
  },
  getBluetoothstatus:function(){
    wx.openBluetoothAdapter({
      success: function (res) {
        console.log(res)
        console.log("蓝牙已打开")
      },
      fail: function () {
        console.log("蓝牙未打开");
        wx.showModal({
          title: '蓝牙未打开',
          content: '请前往设置中心开启蓝牙',
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    });
  }
})