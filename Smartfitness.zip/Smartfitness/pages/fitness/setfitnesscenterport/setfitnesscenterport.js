// pages/fitness/setfitnesscenterport/setfitnesscenterport.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {

    currentports: [],
    list: [
    //   {
    //   content: "三位扭腰器",
    //   isTouchMove: false //默认全隐藏删除
    // }
    ],
    startX: 0, //开始坐标
    startY: 0,
    delBtnWidth: 180,//删除按钮宽度单位（rpx）
    id:'',
    local:'',
    array:[
      
    ],
    equipmentPorts:[],
    portindex:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    if(app.globalData.fitness.location!=undefined){//获取location
      that.setData({
        local: app.globalData.fitness.location
      })
    }
    if (app.globalData.fitness.Id != undefined) { //获取id
      that.setData({
        id: app.globalData.fitness.Id
      })
    }
  
    console.log('获取addequipment',app.globalData.addequipment)
    if (app.globalData.addequipment.length != 0) { //判断app.globalData.addequipment是否为空
      for (var i = 0; i < app.globalData.addequipment.length;i++){
        if (app.globalData.addequipment[i].id == that.data.id) { //不为空则判断app.globalData.addequipment[i].id 和本次传入的id是否相同
          that.setData({ //如果相同则获取app.globalData.addequipment[i]的值
            id: app.globalData.addequipment[i].id,
            local: app.globalData.addequipment[i].local,
            list: app.globalData.addequipment[i].list,
          })
        }else{
          console.log('两次id不相同')
        }
      }
    
      
    }
   
   
    wx.request({ //获取健身中心
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/authorize/getEquipmentTypes', //接口地址

      data: {  //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        var equipmenttype=[];
        for(var i=0;i<res.data.data.length;i++){
          equipmenttype.push({
            etname:res.data.data[i].etname,
            etid: res.data.data[i].idEquipmentPortType
          })
        }
        that.setData({
          array: equipmenttype
        })
       
      }
    })
  
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  bindPickerChange: function (e) {
    console.log(e)
  
    this.setData({
      portindex: e.detail.value
    })
   
    var index = this.data.portindex;
    var name = this.data.array[index];
     console.log(name);
    this.data.list.push({
      content:name,
      txtStyle: "",
     
    });
    this.setData({
      list: this.data.list
    })
  },

  addport:function(e){
    var equipmentPorts = [];
    var equipmentPortType = [];
    var equipment=[];
   
   for(var i=0;i<this.data.list.length;i++){

     equipmentPortType.push({
       idEquipmentPortType:this.data.list[i].content.etid
     })

    equipmentPorts.push({
      epnumber:i+1,
      equipmentPortType: equipmentPortType[i]
    })
   }
      app.globalData.fitness.status='已添加',
        app.globalData.equipment.push({
        emac: app.globalData.fitness.Id,
        equipmentPorts: equipmentPorts
        })

      app.globalData.fitness.equipment = app.globalData.equipment
     console.log('app.globalData.fitness',app.globalData.fitness)

   var a=[];
   a.push({
    id: app.globalData.fitness.Id,
    local: app.globalData.fitness.location,
    list: this.data.list
   })

    app.globalData.addequipment.push({ //  app.globalData.addequipment获取id,local,list的值
     id:app.globalData.fitness.Id,
     local: app.globalData.fitness.location,
     list:this.data.list
     });
  
 
   let arr = app.globalData.addequipment; 
    function update(record) {  //由于多次push数组， app.globalData.addequipment中有多个重复的值，update()函数去掉重复的值，
     let index = 0; 
    for(var i=0;i<arr.length;i++){ 
      if (arr[i].id == record.id) {       
         arr.splice(index, 2);     }   
           index++;   }  
           arr.push(record);
            
            } 
      update(a[0]);
   console.log('app.globalData.addequipment',app.globalData.addequipment)

  wx.navigateBack({
    delta:2
  })
  },


  touchstart: function (e) {
    //开始触摸时 重置所有删除
    this.data.list.forEach(function (v, i) {
      if (v.isTouchMove)//只操作为true的
        v.isTouchMove = false;
    })
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY,
      list: this.data.list
    })
  },
  //滑动事件处理
  touchmove: function (e) {
    var that = this,
      index = e.currentTarget.dataset.index,//当前索引
      startX = that.data.startX,//开始X坐标
      startY = that.data.startY,//开始Y坐标
      touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
      touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
      //获取滑动角度
      angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
    that.data.list.forEach(function (v, i) {
      v.isTouchMove = false
      //滑动超过30度角 return
      if (Math.abs(angle) > 30) return;
      if (i == index) {
        if (touchMoveX > startX) //右滑
          v.isTouchMove = false
        else //左滑
          v.isTouchMove = true
      }
    })
    //更新数据
    that.setData({
      list: that.data.list
    })
  },
  /**
   * 计算滑动角度
   * @param {Object} start 起点坐标
   * @param {Object} end 终点坐标
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
  },
  //删除事件
  del: function (e) {
 var that=this;
  console.log(e);
 var index=e.currentTarget.dataset.index;
 console.log(that.data.list[index]); 
 var content=that.data.list[index].content
    wx.showModal({
      title: '确定删除'+content.etname+'吗',
    
      success: function (res) {
        if (res.confirm) {
         that.data.list.splice(e.currentTarget.dataset.index, 1)
         that.setData({
            list: that.data.list
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  
  },


})