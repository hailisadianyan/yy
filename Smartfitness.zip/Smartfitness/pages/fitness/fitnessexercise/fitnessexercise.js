// pages/fitness/fitnessexercise/fitnessexercise.js
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.min.js');
var util=require('../../../utils/util.js');
var demo = new QQMapWX({
  key: 'VXCBZ-633WO-35YWZ-SAWDU-VXDD5-4FBGJ' // 必填
}); 
var app=getApp();
var Interval;
var connected = 0;
var sendflag=0;
 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    epnumber:'',
    equipment:'',
    starttime:'00:00:00',
    calorie:0,
    zconsume:'',
    num:'',
    hz:'0',
    duration:'',
    status:0,
    month:'',
    day:'',
    hour:'',
    minute:'',
    lat:'',
    log:'',
    address:'',

    deviceId: '',
    serviceId: '',
    characteristicId: '',
    Characteristics: [],
    ble: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('options',options)
    var that= this;
   

    var time = util.formatTime(new Date());
    console.log(time)
    var a = time.split(" ");
    var a0=a[0].split('/');
    var a1=a[1].split(':');
    var Month = a0[1];
    var Day = a0[2]; 
    var Hour = a1[0];
    var Minute = a1[1];
   that.setData({
     month: Month,
     day:Day,
     hour:Hour,
     minute:Minute,
     deviceId:options.deviceId
   })
    wx.getLocation({
      
      type:'gcj02',
      success: function(res) {
         console.log(res);
        that.setData({
           lat:res.latitude,
           log:res.longitude
         })
        demo.reverseGeocoder({
          location: {
            latitude: that.data.lat,
            longitude: that.data.log
          },
          success: function (res) {
            console.log(res);
            console.log(res.result.address);
            that.setData({
              address:res.result.address
            })
          },
          fail: function (res) {
            console.log(res);
          },
          complete: function (res) {
           
          }
        });
      },
    })
  
     wx.showLoading({
       title: '建立蓝牙连接...',
     })
     that.startBlue();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  endExercise:function(){
    var that=this;
    clearInterval(Interval)
    this.setData({
      status: 2
    })
    // that.once()
    wx.showToast({
      title: '健身结束,断开蓝牙',
      icon:'none',
      duration: 2000
    })
  },
 
 startBlue:function(){
    var that=this;
   wx.startBluetoothDevicesDiscovery({
      services:['00000001-1212-EFDE-1523-785FEABCD123'],
     success: function(res) {
      //  console.log('startBluetoothDevicesDiscovery',res)
       that.getBuletooth();
       that.onBluetooth();
     },
   })
  },
  getBuletooth:function(){
    var that = this;
    wx.getBluetoothDevices({
      success: function(res) {
        res.devices.forEach(function(item,index){
          var name=item.name;
          var isMy=name.indexOf("_");
          if(isMy>-1){
            that.data.ble.push({
              RSSI:item.RSSI,
              deviceId:item.deviceId,
              name:name.substring(0,isMy),
              type:name.substring(isMy+1,name.length)
            });
            that.setData({
              ble:that.data.ble
            })
          }
        })

      },
    })
  },
  onBluetooth:function(){
    var that = this;
     var flag=0; 
    wx.onBluetoothDeviceFound(function(res){
      // console.log('找到新设备:', res);
       if(res.devices[0].deviceId==that.data.deviceId){
         flag=1;
        console.log('找到新设备',res);
        console.log('输出res.devices[0].deviceId',res.devices[0].deviceId)
        that.createBLE();
        // console.log('输出that.data.deviceId', that.data.deviceId)
      }

     })
   setTimeout(function(){
     wx.hideLoading()
    if(flag==0){
      // console.log('未扫描到设备');
      wx.showToast({
        title: '未扫描到设备',
        icon: 'none', 
        duration:2000
      })
      setTimeout(function(){
        wx.navigateBack({
          delta: 99
        })
      },2000)
     
    }
   },10000)
   },
  stopSearch:function(){
    wx.stopBluetoothDevicesDiscovery({
      success: function (res) {
        console.log('停止搜索蓝牙：',res)
      }
    })
  },
   createBLE:function(){ //创建蓝牙连接。如果成功就结束蓝牙搜索
     var that=this;
     wx.createBLEConnection({
       deviceId: that.data.deviceId,
       success: function(res) {
         console.log('创建蓝牙连接成功：',res)
         that.stopSearch();
         that.getBLEDeviceServices();
       },
     })
   },
  getBLEDeviceServices:function(){
    var that=this;
    wx.getBLEDeviceServices({
      deviceId: that.data.deviceId,
      success: function(res) {
        console.log('device services:', res.services)
        that.setData({ services: res.services });
        console.log('device services:', that.data.services[1].uuid);
        that.setData({ serviceId: that.data.services[1].uuid });
        console.log('--------------------------------------');
        console.log('device设备的id:', that.data.deviceId);
        console.log('device设备的服务id:', that.data.serviceId);
       that.getBLEDeviceCharacteristics()
      },
    })
  },
  getBLEDeviceCharacteristics:function(){
    var that=this;
    wx.getBLEDeviceCharacteristics({
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
      deviceId:that.data.deviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId:that.data.serviceId,
      success: function (res) {
        var Characteristics=[];
        // console.log('device getBLEDeviceCharacteristics:', res.characteristics)
        for(var i=0;i<res.characteristics.length;i++){
          Characteristics.push({
            characteristicId:res.characteristics[i].uuid
          })
        }
        that.setData({
          Characteristics: Characteristics
        })
        // console.log('获取Characteristics：', Characteristics)
        that.notifyBLECharacteristicValueChange();
      }

    })

  },
  notifyBLECharacteristicValueChange:function(){
    var that=this;
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接  
      deviceId:that.data.deviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId:that.data.serviceId,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.Characteristics[0].characteristicId,
      success: function (res) {
      
        that.onBLECharacteristicValueChange();
       
       if(res.errCode==0){
         wx.hideLoading();
         that.setData({
         status:1
         })
       }
      }
    })
  },
  onBLECharacteristicValueChange:function(){
    var that=this;
    wx.onBLECharacteristicValueChange(function (res) {
      var result='';
      // console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
      // console.log('输出res.value',res.value)
      result=res.value;
    
      var data = that.ab2hex(result).slice(0, 4) == '5501' ?that.ab2hex(result):'';
       console.log('ascdata:', data)
      // console.log('数据:', data.slice(6,19))
      // console.log('校验码',data.slice(20,26))
      var header=data.slice(0,4);
      var status=data.slice(4,6);
      if(status=='a8'){
        var epnumber = data.slice(6, 8);
        var fitnessnum = data.slice(8, 12)
        var fitnessduration = data.slice(12, 16);
        var fitnessconsume = data.slice(16, 20);
        var fitnesshz=data.slice(20,24);
        var fs=fitnessnum.split('');
        var num= parseInt(fs[0], 16) * 16 + parseInt(fs[1], 16) + parseInt(fs[2], 16) * 16 * 16 * 16 + parseInt(fs[3], 16) * 16 * 16;
        var fd = fitnessduration.split('');
        var duration = parseInt(fd[0], 16) * 16 + parseInt(fd[1], 16) + parseInt(fd[2], 16) * 16 * 16 * 16 + parseInt(fd[3], 16) * 16 * 16;
        var fc = fitnessconsume.split('');
        var consume =parseInt(fc[0], 16) * 16 + parseInt(fc[1], 16) + parseInt(fc[2], 16) * 16 * 16 * 16 + parseInt(fc[3], 16) * 16 * 16;
        var fh=fitnesshz.split('');
        var hz = parseInt(fh[0], 16) * 16 + parseInt(fh[1], 16) + parseInt(fh[2], 16) * 16 * 16 * 16 + parseInt(fh[3], 16) * 16 * 16;
       
      }
      if(status=='a7'){
        console.log('结束了');
        that.setData({
          status:2
        })
        wx.closeBluetoothAdapter({
          success: function (res) {
            console.log(res)
            that.once()
          }
        })
    
       
        console.log('结束后',that.data.starttime, that.data.calorie)
      }

      // console.log(duration, consume, num, hz, epnumber)
      var time = util.SecondToDate(duration)
      var enumber=epnumber.split('')[1]
      var kconsume=(consume/1000).toFixed(3)
      var zconsume='';
       if(kconsume>1){
         zconsume = kconsume.toFixed(0)
       }
      if(hz>0){
        sendflag=hz;
      }
      that.setData({
        duration: duration,
        starttime: time,
        calorie: kconsume,
        zconsume: zconsume,
        num:num,
        hz: sendflag,
        epnumber: enumber
      })
      console.log(that.data.deviceId, that.data.epnumber)
      that.getEquipmentType();
    
    })
    wx.onBLEConnectionStateChange(function (res) {
      // 该方法回调中可以用于处理连接意外断开等异常情况
    
      console.log(`device ${res.deviceId} state has changed, connected: ${res.connected}`)
      console.log('connected:',res.connected)
    
      if(res.connected==false){
        that.createBLE();
        connected++;
        console.log(connected)
      } 
      if(res.connected==true){
        connected=0
      }
      if(connected>1){
      
        that.setData({ 
          status: 2
        })
        wx.closeBluetoothAdapter({
          success: function (res) {
            console.log(res)
            that.once()
          
          }
        })
      }
      setTimeout(function () {
        if (connected > 0) {
          console.log('没连接上')

          that.setData({
            status: 2
          })
          wx.closeBluetoothAdapter({
            success: function (res) {
              console.log(res)
              that.once()
             
            }
          })

        }
      }, 10000)
    })
 
  },
  ab2hex:function(buffer) {
    var hexArr = Array.prototype.map.call(
      new Uint8Array(buffer),
      function (bit) {
        return ('00' + bit.toString(16)).slice(-2)
      }
    )
      return hexArr.join('');
  },
 uploadfitnessdata:function(){
  
   var that = this;
   console.log(that.data.deviceId, that.data.epnumber, that.data.calorie, that.data.duration, that.data.hz, that.data.num)
   wx.request({
     url: app.globalData.Url +'/OutdoorFitness/app/user/fitness/addUserFitnessRecord', //接口地址
     data: {  //参数为json格式数据
       emac:that.data.deviceId,
       epnumber: that.data.epnumber,
       frconsume:that.data.calorie,
       frduration: that.data.duration,
       frequency:that.data.hz,
       frtimes:that.data.num
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token':wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log('上传健身记录',res.data)
       sendflag=0
      
     }
   })
 },
  getEquipmentType:function(){
    var that = this;
    wx.request({ 
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getEquipmentType', //接口地址
      data: {  //参数为json格式数据
        emac: that.data.deviceId,
        epnumber: that.data.epnumber,
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log('获取设备类型：',res.data)
        that.setData({
          equipment:res.data.data.etname
        })
      }
    }) 
  },
  once:function(){
    var that=this;
    if (app.globalData.tag) {
      that.uploadfitnessdata();
      app.globalData.tag = false;
    } else {
      return;
    }
  },
  goGuide:function(){
    var that=this
    var epnumber = that.data.epnumber
    wx.navigateTo({
      url: '../../fitness/guidance/guidance?epnumber=' + epnumber,
    })
  }
})

