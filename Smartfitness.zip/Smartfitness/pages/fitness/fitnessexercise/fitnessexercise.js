// pages/fitness/fitnessexercise/fitnessexercise.js
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.min.js');
var util=require('../../../utils/util.js');
var demo = new QQMapWX({
  key: 'VXCBZ-633WO-35YWZ-SAWDU-VXDD5-4FBGJ' // 必填
}); 

Page({

  /**
   * 页面的初始数据
   */
  data: {
    equipment:'划船器',
    starttime:'00:00:00',
    calorie:0,
    status:0,
    month:'',
    day:'',
    hour:'',
    minute:'',
    lat:'',
    log:'',
    address:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that= this;
    

    var time = util.formatTime(new Date());
    console.log(time)
    var a = time.split(" ");
    var a0=a[0].split('/');
    var a1=a[1].split(':');
    var Month = a0[1];
    var Day = a0[2]; 
    var Hour = a1[0];
    var Minute = a1[1];
   that.setData({
     month: Month,
     day:Day,
     hour:Hour,
     minute:Minute,
   })
    wx.getLocation({
      
      type:'gcj02',
      success: function(res) {
         console.log(res);
        that.setData({
           lat:res.latitude,
           log:res.longitude
         })
        demo.reverseGeocoder({
          location: {
            latitude: that.data.lat,
            longitude: that.data.log
          },
          success: function (res) {
            console.log(res);
            console.log(res.result.address);
            that.setData({
              address:res.result.address
            })
          },
          fail: function (res) {
            console.log(res);
          },
          complete: function (res) {
           
          }
        });
      },
    })
  
 

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  startExercise:function(){
    this.setData({
      status:1
    })
  },
  endExercise:function(){
    this.setData({
      status: 2
    })
    wx.showToast({
      title: '健身结束,断开蓝牙',
      icon:'none',
      duration: 2000
    })
  },

 
})