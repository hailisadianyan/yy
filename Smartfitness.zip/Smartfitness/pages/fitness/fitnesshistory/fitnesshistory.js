var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    day:{
      date: {
        month: 1,
        day: 27
      },
      minute: 102,
      num: 2,
      consume: 300,
    },
   week:{
     date: {
      startdate:'1/1',
      enddate:'1/7'
     },
     minute: 102,
     num: 30,
     consume: 300,
   },
   month:{
     date: {
       year: 2018,
       month: 1
     },
     minute: '33.20',
     num: 60,
     consume: 4261,
   },

   dayconsume: [1204, 1304, 1344, 1634, 1244],
   dayexercisetime: ['08:30','10:30',"15:30","18:00","20:00"],
   dayheight: [],
   daycalories: []  ,
   
   weekconsume: [1204, 1304, 1344, 1634, 1244,1500,1800],
   weekexercisetime: ['星期一', '星期二', "星期三", "星期四", "星期五", "星期六", "星期日"],
   weekheight: [],
   weekcalories: [],
 
   monthconsume: [1204, 1304, 1344, 1634, 1244, 1734, 1324, 1424, 1244, 1534, 1324, 1364, 1454, 1454, 1844, 1124, 1024, 1024, 1824, 1424, 1324, 1324, 1024],
  monthexercisetime: [],
  monthheight: [],
  monthcalories: [], 


    fitness: [
      {
      fitnessname: 'xx健身器材',//健身器材名
      times: 1, //健身次数
      starttime:'21:57',//开始时间
      exercisetime: '00:15:13',//锻炼时长
      exerciseconsumption: '140', //锻炼消耗
      },
      {  
        fitnessname: '杠铃',//健身器材名
        times: 1, //健身次数
        starttime: '8:30',//开始时间
        exercisetime: '00:30:25',//锻炼时长
        exerciseconsumption: '365', //锻炼消耗
      }
      ],
   

  
   fitnesshistory:[
     {
       date: {
         month: 1,
         day: 17
       },
       historydata: [
         {
           fitnessname: 'xx健身器材',//健身器材名
           times: 1, //健身次数
           starttime: '21:57',//开始时间
           exercisetime: '00:15:13',//锻炼时长
           exerciseconsumption: '140', //锻炼消耗
         },
         {
           fitnessname: '杠铃',//健身器材名
           times: 1, //健身次数
           starttime: '8:30',//开始时间
           exercisetime: '00:30:25',//锻炼时长
           exerciseconsumption: '365', //锻炼消耗
         }
       ]
     },
     {
       date: {
         month: 1,
         day: 16
       },
       historydata: [
         {
           fitnessname: '太空漫步机',//健身器材名
           times: 1, //健身次数
           starttime: '20:37',//开始时间
           exercisetime: '00:23:50',//锻炼时长
           exerciseconsumption: '120', //锻炼消耗
         },
         {
           fitnessname: '拉力器',//健身器材名
           times: 1, //健身次数
           starttime: '8:30',//开始时间
           exercisetime: '00:20:25',//锻炼时长
           exerciseconsumption: '75', //锻炼消耗
         }
       ]
     },
    
   ],

     height:'',
    hartTitle: '总成交量',
    isMainChartDisplay: true,
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var that=this;
    var historylength = this.data.fitnesshistory.length;
    var historydatalength = this.data.fitnesshistory[0].historydata.length;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res);
        // 计算主体部分高度,单位为px
        that.setData({
          height: res.windowHeight + 180 * (historylength * historydatalength) //得到swiper中内容的总高度
        })
      }
    });

   

 
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (e) {
    var that = this;
    that.day();
    that.week();
    that.month();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  swiperTab: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },

  //点击切换
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  
  },
  day:function(){
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.dayconsume.length; i++) {
      b.push(Math.ceil(((this.data.dayconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      dayheight: b
    })
    console.log(this.data.dayheight)
    for (var i = 0; i <this.data.dayexercisetime.length; i++) {
    
      var histogram = {};
      for (var j = 0; j < this.data.dayheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.dayheight[j];
          histogram.date = this.data.dayexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      daycalories: calories
    })
  },
  week: function () {
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.weekconsume.length; i++) {
      b.push(Math.ceil(((this.data.weekconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      weekheight: b
    })
    console.log(this.data.weekheight)
    for (var i = 0; i < this.data.weekexercisetime.length; i++) {
     
      var histogram = {};
      for (var j = 0; j < this.data.weekheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.weekheight[j];
          histogram.date = this.data.weekexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      weekcalories: calories
    })
  },
  month:function(){
    var myDate = new Date();
    var month = myDate.getMonth() + 1  //获取当前月份(0-11,0代表1月，所以要加1);
    var day = myDate.getDate();//获取当前日（1-31）
    if (month < 10) {
      month = "0" + month;
    }
    var arr1 = [];
    for (var i = 1; i <= day; i++) {
      if (i >= 0 && i <= 9) {
        i = "0" + i;
      }
      arr1.push(month + "/" + i);
    }
    this.setData({
      monthexercisetime: arr1
    })
    console.log(this.data.monthexercisetime);
    var b = [];
    for (var i = 0; i < this.data.monthconsume.length; i++) {
      b.push(Math.ceil(((this.data.monthconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      monthheight: b
    })


    var calories = []

    for (var i = 0; i < this.data.monthexercisetime.length; i++) {
    
      var histogram = {};
      for (var j = 0; j < this.data.monthheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.monthheight[j];
          histogram.date = this.data.monthexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      monthcalories: calories
    })
  }
})