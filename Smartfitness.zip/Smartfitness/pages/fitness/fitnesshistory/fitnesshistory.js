var app = getApp();
var util = require('../../../utils/util.js'); 

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
   daymonth:'', //月份
   dayday:'',  //日期
   dayminute:'', //每天锻炼的时长
   daynum:'', //每天锻炼的次数
   dayconsumes:'', //每天锻炼的消耗
   daymax:'',      //获取每天健身时长数据的最大值
   dayduration: [], //健身的时长，用作柱状图的算高的数据
   dayexercisetime: [],//健身开始的时间
   dayheight: [], //设置柱状图的高
   daycalories: [], 
   fitness: [],//健身详细数据

   weekfirstday:'',
   weekendday:'',
   weekminute:'',
   weeknum:'',
   weekconsumes:'',
   weekmax:'',
   weekexercisetime: ['星期一', '星期二', "星期三", "星期四", "星期五", "星期六", "星期日"],
   week: [],
   weekheight: [],
   weekcalories: [],
   weekfitnesshistory: [

   ],

   monthyear:'',
   monthmonth:'',
   monthminute: '',
   monthnum: '',
   monthconsumes: '', 
   monthmax:'',
   monthexercisetime: [],
   monthheight: [],
   monthcalories: [], 
   fitnesshistory:[ ],

     height:'',
    hartTitle: '总成交量',
    isMainChartDisplay: true,
  
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {  
    var that=this;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res);
        // 计算主体部分高度,单位为px
        that.setData({
          height: res.windowHeight * 2 //得到swiper中内容的总高度
        })
      }
    });
    that.dayTimes();
    that.weekTimes();
    that.monthTimes();
    },
      /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (e) {
    var that = this;
   
    
    that.month();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  swiperTab: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },

  //点击切换
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  
  },

  day:function(){ //每日的柱状图
    var calories = []
    var b = [];
    // console.log(this.data.dayduration);
    // console.log(this.data.daymax)
    for (var i = 0; i < this.data.dayduration.length; i++) {
      b.push(Math.ceil(((this.data.dayduration[i] /this.data.daymax).toFixed(2) * 100)))
    }
    this.setData({
      dayheight: b
    })
    // console.log(this.data.dayheight)
    for (var i = 0; i <this.data.dayexercisetime.length; i++) {
    
      var histogram = {};
      for (var j = 0; j < this.data.dayheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.dayheight[j];
          histogram.date = this.data.dayexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    // console.log(calories);
    this.setData({
      daycalories: calories
    })
  },

  week: function () {//每周的柱状图
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.week.length; i++) {
      b.push(Math.ceil(((this.data.week[i].time / this.data.weekmax).toFixed(2) * 100)))
    }
    this.setData({
      weekheight: b
    })
    console.log('this.data.week',this.data.week)
    for (var i = 0; i < this.data.week.length; i++) {
     
      var histogram = {};
      for (var j = 0; j < this.data.weekheight.length; j++) {
        if (i == j) {
          histogram.time = this.data.weekheight[j];
          histogram.date = this.data.week[i].name;
          histogram.value=this.data.week[i].value;
          calories.push(histogram);
        }
      }
    }
    // console.log(calories);
    this.setData({
      weekcalories: calories
    })
  },

  month: function () {//每月的柱状图
 
    var b = [];
    for (var i = 0; i < this.data.monthexercisetime.length; i++) {
      b.push(Math.ceil(((this.data.monthexercisetime[i].time /this.data.monthmax).toFixed(2) * 100)))
    }
    this.setData({
      monthheight: b
    })


    var calories = []

    for (var i = 0; i < this.data.monthexercisetime.length; i++) {
    
      var histogram = {};
      for (var j = 0; j < this.data.monthheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.monthheight[j];
          histogram.date = this.data.monthexercisetime[i].name;
          calories.push(histogram);
        }
      }
    }
    // console.log(calories);
    this.setData({
      monthcalories: calories
    })
  },

 dayTimes:function(){
   var that=this;
   var time = util.formatTime(new Date());
   var month=time.split(' ')[0].split('/')[1];//获取当前月份
   var day= time.split(' ')[0].split('/')[2]; //获取当前日期
   
   wx.request({ //获取每日总的健身数据
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getTimesTotalRecords', //接口地址
     data: {  //参数为json格式数据
       dayType:1,
       frcreatetime:time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log(res.data)
       if(res.data.data){
        that.setData({
          daymonth: month,
          dayday: day,
          dayconsumes: res.data.data.consume,
          dayminute:Math.ceil(res.data.data.duration/60) ,
          daynum: res.data.data.times
        })
       }else if(res.data.data==null){
         that.setData({
           daymonth: month,
           dayday: day,
           dayconsumes: 0,
           dayminute: 0,
           daynum: 0
         })
       }
     }
   })
   wx.request({ //获取每日总的健身数据
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getFitnessRecords', //接口地址
     data: {  //参数为json格式数据
       dayType: 1,
       frcreatetime: time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
      //  console.log('每日的详细信息:',res.data)
        var Fitness=[];
       for (var i = res.data.data.length-1;i>=0;i--){
           that.data.dayexercisetime.push(util.formatTimeThree(res.data.data[i].frcreatetime))
           that.data.dayduration.push(res.data.data[i].frduration)
           Fitness.push({
             fitnessname: res.data.data[i].etname,
             starttime: util.formatTimeThree(res.data.data[i].frcreatetime),
             exercisetime: util.SecondToDate(res.data.data[i].frduration),
             exerciseconsumption: res.data.data[i].frconsume
           })
         }
        //  console.log('每日健身数据：', that.data.fitness)
        //  console.log('每日的健身时间：',that.data.dayexercisetime)
        //  console.log('每日的健身时长：', that.data.dayduration)
         var max = util.Max(that.data.dayduration);
        //  console.log(max)
          that.setData({
            daymax:max,
            fitness:Fitness
          })
          that.day();
     
     }
   })
 },

weekTimes: function () {
   var that = this;
   var time = util.formatTime(new Date());
   var weekfirstday=that.getWeek(0);
   var  weekendday=that.getWeek(6);
   var week=[]
   for(var i=0;i<7;i++){ //获取一周的日期

   week.push({
     value: util.Week(i), //week.value 一周的日期 2018-08-01
     name: that.data.weekexercisetime[i]  //week.name 星期一到星期天
   })
   }
   that.setData({
     week:week
   })

   wx.request({ //获取每周的总信息
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getTimesTotalRecords', //接口地址
     data: {  //参数为json格式数据
       dayType: 2,
       frcreatetime: time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log(res.data)
       if (res.data.data) {
         that.setData({
           weekfirstday: weekfirstday, //每周第一天
           weekendday: weekendday,  //最后一天
           weekconsumes:res.data.data.consume, //周健身消耗
           weekminute: Math.ceil(res.data.data.duration / 60),//周健身时长
           weeknum: res.data.data.times//周健身次数
         })
       } else if (res.data.data == null) {
         that.setData({
           weekfirstday: weekfirstday,
           weekendday: weekendday,
           weekconsumes: 0,
           weekminute: 0,
           weeknum: 0
         })
       }
     }
   })
   wx.request({ //获取每周详细的健身数据
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getFitnessRecords', //接口地址
     data: {  //参数为json格式数据
       dayType: 2,
       frcreatetime: time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log('每周的详细信息:', res.data)
      var weekFitness=[];
      var weekFitnessdate=[];
      var adate = [];
  
    for(var i=0;i<res.data.data.length;i++){
        weekFitness.push({ //获取周每天健身的详细信息
             fitnesstime: util.formatTimeTwo(res.data.data[i].frcreatetime),
             fitnessname: res.data.data[i].etname,
             starttime: util.formatTimeThree(res.data.data[i].frcreatetime),
             exercisetime: util.SecondToDate(res.data.data[i].frduration),
             exerciseconsumption: res.data.data[i].frconsume
         })
       weekFitnessdate.push({ //获取周每天的健身总时间
           fitnesstime: util.formatTimeTwo(res.data.data[i].frcreatetime),
           exercisetime: res.data.data[i].frduration,
        })
    }
    console.log('周每天健身数据：', weekFitness)
  
    var data =util.ScreenDate(weekFitness) //筛选数据，将同一天的数据放在一个数组中
     for(var k in data){
       console.log('输出data[k]',data[k]);
       adate.push({ 
         historydata:data[k], 
         weekdate: data[k][0].fitnesstime.split('-') 
         })
     }
     console.log('adate',adate)
var a = util.trans(weekFitnessdate) //数组把相同key 值合并，value相加
 var timemax=[] //获取week[i].time的最大值

 for(var i=0;i<week.length;i++){ //将一周有时长的数据，放入week里
   for(var j=0;j<a.length;j++){
     if (week[i].value == a[j].fitnesstime){
       week[i].time = a[j].exercisetime
       timemax.push(week[i].time)
     }
    }
  }
 var weekmax = util.Max(timemax);//获取时长的最大值
  // console.log('weektime',week)

    that.setData({
      weekfitnesshistory:adate,
      week:week,
      weekmax:weekmax
    })

    that.week(); //调用上面的week（）,画出柱状图 
     }
   })
 },
 monthTimes: function () {
   var that = this;
   var time = util.formatTime(new Date());
   var year = time.split(' ')[0].split('/')[0];//获取当前月份
   var month = time.split(' ')[0].split('/')[1]; //获取当前日期

   wx.request({ //获取每月的总数据
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getTimesTotalRecords', //接口地址
     data: {  //参数为json格式数据
       dayType: 3,
       frcreatetime: time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log(res.data)
       if (res.data.data) {
         that.setData({
           monthyear: year,
           monthmonth: month,
           monthconsumes: res.data.data.consume,
           monthminute:(res.data.data.duration/3600).toFixed(1),
           monthnum: res.data.data.times
         })
       } else if (res.data.data == null) {
         that.setData({
           monthyear: year,
           monthmonth:month,
           monthconsumes: 0,
           monthminute: 0,
           monthnum: 0
         })
       }
     }
   })

   var montharr=[]
   var myDate = new Date();
   var year=myDate.getFullYear();
   var month = myDate.getMonth() + 1  //获取当前月份(0-11,0代表1月，所以要加1);
   var day = myDate.getDate();//获取当前日（1-31）
   if (month < 10) {
     month = "0" + month;
   }
   var arr1 = [];
   var arr2=[];
   for (var i = 1; i <= day; i++) {
     if (i<10) {
       i = "0" + i;
     }
     arr1.push(month + "/" + i);
     arr2.push(year+'-'+month+'-'+i)
    
   }
   for(var i=0;i<arr1.length;i++){
     montharr.push({
       value: arr2[i],
       name: arr1[i]
     })
   }
   console.log('arr',arr1.length,arr2,montharr)
   this.setData({
     monthexercisetime: montharr
   })
   
  //  console.log(this.data.monthexercisetime);
 
   wx.request({ //获取每月详细的健身数据
     url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getFitnessRecords', //接口地址
     data: {  //参数为json格式数据
       dayType: 3,
       frcreatetime: time
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log('每月的详细信息:', res.data)
       var monthFitness = [];
       var monthFitnessdate = [];
       var adate = [];

       for (var i = 0; i < res.data.data.length; i++) {
         monthFitness.push({ //获取月每天健身的详细信息
           fitnesstime: util.formatTimeTwo(res.data.data[i].frcreatetime),
           fitnessname: res.data.data[i].etname,
           starttime: util.formatTimeThree(res.data.data[i].frcreatetime),
           exercisetime: util.SecondToDate(res.data.data[i].frduration),
           exerciseconsumption: res.data.data[i].frconsume
         })
         monthFitnessdate.push({ //获取周月每天的健身总时间
           fitnesstime: util.formatTimeTwo(res.data.data[i].frcreatetime),
           exercisetime: res.data.data[i].frduration,
         })
       }
      //  console.log('月每天健身数据：', monthFitness)

       var data = util.ScreenDate(monthFitness) //筛选数据，将同一天的数据放在一个数组中
       for (var k in data) {
         //  console.log(data[k]);
         adate.push({
           historydata: data[k],
           monthdate: data[k][0].fitnesstime.split('-')
         })
       }
      //  console.log('monthadate', adate)
       var a = util.trans(monthFitnessdate) //数组把相同key 值合并，value相加
      //  console.log('montha',a)
       var timemax = [] //获取month[i].time的最大值
       var monthexercisetime = that.data.monthexercisetime
      //  console.log('met',monthexercisetime)
       for (var i = 0; i <monthexercisetime.length; i++) { //将一月有时长的数据，放入week里
         for (var j = 0; j < a.length; j++) {
           if (monthexercisetime[i].value == a[j].fitnesstime) {
             monthexercisetime[i].time = a[j].exercisetime
             timemax.push(monthexercisetime[i].time)
           }
         }
       }
       var monthmax = util.Max(timemax);//获取时长的最大值
      
       that.setData({
         fitnesshistory: adate,
         monthexercisetime: monthexercisetime,
         monthmax: monthmax
       })
      //  console.log(that.data.monthexercisetime);
      //  console.log(that.data.monthmax)
       that.month();
     }
   })


 },
 getWeek:function(i) {
    var now = new Date();
    var firstDay= new Date(now - (now.getDay() - 1) * 86400000);
    firstDay.setDate(firstDay.getDate() + i);
    var mon = Number(firstDay.getMonth()) + 1;
    var day = firstDay.getDate();
    if (day<10){
      day = "0" + day
    }
    if(mon<10){
      mon='0'+mon
    }
    return mon + "/" +day;
  },

})