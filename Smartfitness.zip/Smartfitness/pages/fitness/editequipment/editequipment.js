// pages/fitness/editequipment/editequipment.js
var recordStartX = 0;
var currentOffsetX = 0;
var app = getApp();
var equimentdata = [];
// var app.globalData.editflag=true;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isAuthorize: '',
    details: {},
    items: [],
    startX: 0, //开始坐标
    startY: 0,
    editIndex: 0,
    delBtnWidth: 150,//删除按钮宽度单位（rpx）
    eqment:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    var equipment = [];
    that.setData({
      isAuthorize: wx.getStorageSync('isAuthorize')
    })
  
    console.log('app.globalData.editequipment', app.globalData.editequipment)

    if (app.globalData.editequipment.length != 0) {
      for (var i = 0; i < app.globalData.editequipment.length; i++) {
        equipment.push({
          id: app.globalData.editequipment[i].id,
          local: app.globalData.editequipment[i].local
        })
      }
    }else{
      that.getFitnessEquiment();
    }
 

    // console.log('输出equipment', equipment, equimentdata)
    that.setData({
      items: equipment
    })
    // console.log('items',this.data.items)
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
 

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  addFitnessport: function () {

    wx.scanCode({
      success: (res) => {
        console.log(res)
        app.globalData.editfitness.Id = res.result
        wx.navigateTo({
          url: '../../fitness/editport/editport',
        })
      }
    })
  },
  Equimentcontent: function (e) {
    console.log('输出Equimentcontent', e,app.globalData.editequipment[0].id)
    var index = e.currentTarget.dataset.index
    var addequipment = app.globalData.editequipment[index].id
    app.globalData.editfitness.Id = addequipment  //点击那个健身中心设备进入设备详情
    console.log(app.globalData.editfitness)
    wx.navigateTo({
      url: '../../fitness/editport/editport'
    })
  },
  getFitnessEquiment: function () {
    var that = this
    var eqdata = [];
    var list = [];
    var content = []
    wx.request({ //获取健身中心下所有设备
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/authorize/getFitnessCenterEquipment', //接口地址

      data: {  //参数为json格式数据
        fcid: app.globalData.editfitnesscenter.idFitnessCenter
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log('获取健身中心下所有设备', res.data)
        if (res.data.data != null) {
          var aa= that.once(res.data.data);
          that.setData({
            items: aa
          })
         
        }

      }

    })

  },
  touchstart: function (e) {
    // console.log('输出touchstart的items',this.data.items,e)
    if(!this.data.items){
      return
    }
    //开始触摸时 重置所有删除
    this.data.items.forEach(function (v, i) {
      if (v.isTouchMove)//只操作为true的
        v.isTouchMove = false;
    })
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY,
      items: this.data.items
    })
  },
  //滑动事件处理
  touchmove: function (e) {
    var that = this;
    if (!that.data.items) {
      return
    }
     var index = e.currentTarget.dataset.index,//当前索引
      startX = that.data.startX,//开始X坐标
      startY = that.data.startY,//开始Y坐标
      touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
      touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
      //获取滑动角度
      angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
    that.data.items.forEach(function (v, i) {
      v.isTouchMove = false
      //滑动超过30度角 return
      if (Math.abs(angle) > 30) return;
      if (i == index) {
        if (touchMoveX > startX) //右滑
          v.isTouchMove = false
        else //左滑
          v.isTouchMove = true
      }
    })
    //更新数据
    that.setData({
      items: that.data.items
    })
  },
  /**
   * 计算滑动角度
   * @param {Object} start 起点坐标
   * @param {Object} end 终点坐标
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
  },
  //删除事件
  del: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index
    var idFitnessCenter = that.data.items[index].id
   
    wx.showModal({
      title: '确定删除该设备?',
      content: '确定删除该设备?',
      success: function (res) {
        if (res.confirm) {
          that.data.items.splice(index, 1)
          that.setData({
            items: that.data.items
          })
          console.log(idFitnessCenter)
          wx.request({ //删除健身中心的设备

            url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/authorize/deleteFitnessCenterEquipment', //接口地址

            data: {  //参数为json格式数据
              emac: idFitnessCenter
            },
            header: {
              'content-type': 'application/json',
              'Accept': 'application/json',
              'token': wx.getStorageSync('token')
            },
            method: 'POST',
            success: function (res) {
              console.log(res.data)
            }
          })

        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  once:function(data){
    // console.log('once被执行了')
    var eqdata = [];
    var list=[];
    var content=[];
    var eq=[];
    var  equipment=[]
      if (app.globalData.editflag) {
        for (var i = 0; i < data.length; i++) {
          eqdata.push({
            id: data[i].emac,
            local: app.globalData.editfitnesscenter.fcaddress
          })
      
          app.globalData.editequipment.push({
            id: data[i].emac,
            local: app.globalData.editfitnesscenter.fcaddress,
          }) 
  
          content.push(
             data[i].equipmentPorts
          )
         eq.push({
           emac:data[i].emac
         }) 
        }
       console.log('content',content)
        var tArray = new Array();   
        for (var k = 0; k < content.length; k++) {      
          tArray[k] = new Array(); 
          
          for (var j = 0; j < content[k].length; j++) {      
            tArray[k][j] = content[k][j].equipmentPortType;  
         
          }
           
        }
        console.log('tArray', tArray) 

        for (var x=0;x< tArray.length;x++){
          list[x]=new Array();
          for (var y = 0; y < tArray[x].length;y++){
            list[x].push({
             content:  {
              etname:tArray[x][y].etname,
              etid: tArray[x][y].idEquipmentPortType
            },
              txtStyle: ""
            })
        
         } 
        }
        console.log('list',list)
      
     
     for(var n=0;n<list.length;n++){
       for (var m = 0; m < app.globalData.editequipment.length;m++){
        if(n==m){
        app.globalData.editequipment[m].list=list[n]
        }
       }
      }
        console.log(app.globalData.editequipment)
        return eqdata;
      } else {
        return;
      }
  },

})