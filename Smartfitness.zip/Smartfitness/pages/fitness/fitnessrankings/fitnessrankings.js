var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    personalname:'闪电侠',
    results:[
      {
        ranking:1,
        headportrait:'../../image/1.jpg',
        name:'阿斯钢',
        exercisetime:42
      },
      {
        ranking: 2,
        headportrait: '../../image/1.jpg',
        name: '啊发生',
        exercisetime: 40
      },
      {
        ranking: 3,
        headportrait: '../../image/1.jpg',
        name: '回家',
        exercisetime: 35
      },
      {
        ranking: 4,
        headportrait: '../../image/1.jpg',
        name: '花果山单行',
        exercisetime: 32
      },
      {
        ranking: 5,
        headportrait: '../../image/1.jpg',
        name: '郭莎莎',
        exercisetime: 31
      },
      {
        ranking: 6,
        headportrait: '../../image/1.jpg',
        name: '复健科',
        exercisetime: 27
      },
      {
        ranking: 7,
        headportrait: '../../image/1.jpg',
        name: '闪电侠',
        exercisetime: 25
      },
      {
        ranking: 8,
        headportrait: '../../image/1.jpg',
        name: '扫地杆',
        exercisetime: 22
      },
      {
        ranking: 9,
        headportrait: '../../image/1.jpg',
        name: '按时',
        exercisetime: 21
      },
    ]
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.results[0])
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})