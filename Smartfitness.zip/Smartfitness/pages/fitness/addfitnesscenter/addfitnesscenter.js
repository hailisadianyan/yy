// pages/fitness/addfitnesscenter/addfitnesscenter.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fitnesscentername:"去设置",
    fitnesscenterlocation:"去设置",
    fitnesscenterequipment:"去设置"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    var that=this;
    if(options.name!=undefined){
      that.setData({
        fitnesscentername: options.name
      })
    }
    if (options.location != undefined) {
      that.setData({
        fitnesscenterlocation: options.location
      })
    }
    if (options.status != undefined) {
      that.setData({
        fitnesscenterequipment: options.status
      })
    }
   

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  setFitnesscenterName:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscentername/setfitnesscentername',
    })
  },
  setFitnesscenterLocation:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterlocation/setfitnesscenterlocation',
    })
  },
  setFitnesscenterEquipment:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterequipment/setfitnesscenterequipment',
    })
  },
  addFitnesscenter:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesscenter/fitnesscenter',
    })
  }
})