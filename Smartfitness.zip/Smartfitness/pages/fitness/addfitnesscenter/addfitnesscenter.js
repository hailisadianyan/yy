// pages/fitness/addfitnesscenter/addfitnesscenter.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fitnesscentername:"去设置",
    fitnesscenterlocation:"去设置",
    fitnesscenterequipment:"去设置",
    disabled:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
   var that=this;
 
   if (app.globalData.fitness.name!=undefined){
      this.setData({
        fitnesscentername: app.globalData.fitness.name,
      })
    }
   if (app.globalData.fitness.location != undefined) {
     this.setData({
       fitnesscenterlocation: app.globalData.fitness.location
     })
   }
   if (app.globalData.fitness.status != undefined) {
     this.setData({
       fitnesscenterequipment: app.globalData.fitness.status
     })
   }
    console.log(app.globalData.fitness.equipment, app.globalData.fitness.location, app.globalData.fitness.name)
    if (app.globalData.fitness.equipment == undefined || app.globalData.fitness.location == undefined || app.globalData.fitness.name == undefined) {
      this.setData({
        disabled: true
      })
    } else {
      this.setData({
        disabled: false
      })
    }


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  setFitnesscenterName:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscentername/setfitnesscentername',
    })
  },
  setFitnesscenterLocation:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterlocation/setfitnesscenterlocation',
    })
  },
  setFitnesscenterEquipment:function(){
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterequipment/setfitnesscenterequipment',
    })
  },
  addFitnesscenter:function(){
    console.log('获取app.globalData.fitness:', app.globalData.fitness)
    console.log('获取app.globalData.fitness.equipment:', app.globalData.fitness.equipment)
  
    console.log(app.globalData.fitness.equipment, app.globalData.fitness.location, app.globalData.fitness.name)
   
    wx.request({ //获取健身中心
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/authorize/addNewFitness', //接口地址

      data: {  //参数为json格式数据
        equipment: app.globalData.fitness.equipment,
        fcaddress: app.globalData.fitness.location,
        fcdefinition: app.globalData.fitness.name,
        fclatitude: app.globalData.fitness.lat,
        fclongitude: app.globalData.fitness.log,
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)

        if (res.data.code == 1000) {
          wx.showToast({
            title: '添加成功',
          })
          wx.navigateBack({
            delta: 1
          })
        }
        if (res.data.code == 1001) {
          wx.showToast({
            title: '添加失败,该设备可以已经添加过健身中心',
            icon: 'none'
          })
          wx.navigateBack({
            delta: 1
          })
        }
      }
    })
    
   
  },
  addCenter:function(){

  
  }
})