// pages/fitness/fitnesscentermap/fitnesscentermap.js
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({
  data: {
    lat:'22.608770371',
    log:'113.887031555',
    height:'',
    markers: [{
      iconPath: "../../image/fitness_center_1.png",
      id: 0,
      latitude: 22.60137,
      longitude: 113.88743,
      width: 50,
      height: 50,
      callout: {
        content: 'xx健身中心',
        fontSize: 12,
        color: '#ffffff',
        bgColor: '#000000',
        padding:5,
        borderRadius: 10,
        boxShadow: '4px 8px 16px 0 rgba(0)',
        display: 'ALWAYS'
      }
    }, {
      iconPath: "../../image/fitness_center_1.png",
      id: 1,
      latitude: 22.60752,
      longitude: 113.88754,
      width: 50,
      height: 50
    },
    {
      iconPath: "../../image/fitness_center_1.png",
      id: 2,
      latitude: 22.60339,
      longitude: 113.88542,
      width: 50,
      height: 50
    },
    {
      iconPath: "../../image/fitness_center_1.png",
      id: 3,
      latitude: 22.60245,
      longitude: 113.89117,
      width: 50,
      height: 50
    }
    ]

  },
  onLoad:function(options){
    var that=this;
  //  wx.getLocation({
  //    success: function(res) {
  //      console.log(res)
  //    },
  //  })
    that.data.markers.push({
      iconPath: "../../image/punctuation.png",
      id: 4,
      latitude: 22.608770371,
      longitude: 113.887031555,
      width: 50,
      height: 50 
    })
   that.setData({
     markers: this.data.markers
   })

   wx.getSystemInfo({
     success: function (res) {
       console.log(res);
       // 可使用窗口宽度、高度
       console.log('height=' + res.windowHeight);
       console.log('width=' + res.windowWidth);
       // 计算主体部分高度,单位为px
     that.setData({
        height: res.windowHeight+'px'
      })
     }
   })
   
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  fitnesscenter:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesscenter/fitnesscenter',
    })
  }
})