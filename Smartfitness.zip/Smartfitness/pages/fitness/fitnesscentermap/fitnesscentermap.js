// pages/fitness/fitnesscentermap/fitnesscentermap.js
var app=getApp()
var QQMapWX = require('../../../libs/qqmap-wx-jssdk.js');
var qqmapsdk;
Page({
  data: {
    lat:'',
    log:'',
    height:'',
    markers: [
    
    ]

  },
  onLoad:function(options){

    var that = this;
    var fitnessdata = [];
    var mk=that.data.markers
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)

        var lat = res.latitude.toFixed(6);
        var log = res.longitude.toFixed(6)
      
        mk .push({
          latitude: lat,
          longitude: log,
          iconPath: '../../image/fitness_center_1.png',
          width: 50,
          height: 50,
          id: 2,
          callout: {
            content: lat + '  ' + log + '公里',
            fontSize: 12,
            color: '#ffffff',
            bgColor: '#000000',
            padding: 5,
            borderRadius: 10,
            boxShadow: '4px 8px 16px 0 rgba(0)',
            display: 'ALWAYS'
          }
        })
        that.setData({
          lat:lat,
          log:log,
          markers:mk
        })
        console.log(lat,log)
        wx.request({ //获取健身中心
          url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getFitnessCenters', //接口地址

          data: {  //参数为json格式数据
            clatitude: lat,
            clongitude: log
          },
          header: {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'token': wx.getStorageSync('token')
          },
          method: 'POST',
          success: function (res) {
            console.log(res.data)
            for (var i = 0; i < res.data.data.length; i++) {
              fitnessdata.push({
                latitude: res.data.data[i].fclatitude,
                longitude: res.data.data[i].fclongitude,
                iconPath: '../../image/fitness_center_1.png',
                width: 50,
                height: 50,
                id:i+1,
                callout:{
                   content: res.data.data[i].fcdefinition + '  ' + res.data.data[i].distance.toFixed(2)+'公里',
                   fontSize: 12,
                   color: '#ffffff',
                   bgColor: '#000000',
                   padding:5,
                   borderRadius: 10,
                   boxShadow: '4px 8px 16px 0 rgba(0)',
                   display: 'BYCLICK'
                }
              })
            }
            that.setData({
              markers: fitnessdata
            })
          }
        })
      },

    }) 
   wx.getSystemInfo({
     success: function (res) {
       console.log(res);
       // 可使用窗口宽度、高度
       console.log('height=' + res.windowHeight);
       console.log('width=' + res.windowWidth);
       // 计算主体部分高度,单位为px
     that.setData({
        height: res.windowHeight+'px'
      })
     }
   })
   
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
    
  },
  controltap(e) {
    console.log(e.controlId)
  },

  fitnesscenter:function(){
    wx.navigateTo({
      url: '../../fitness/fitnesscenter/fitnesscenter',
    })
  },
  Search: function (e) {  //查询健身中心
    var that=this;
    var fitnessdata = [];
    wx.request({ //获取健身中心
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/getFitnessCenters', //接口地址

      data: {  //参数为json格式数据
        clatitude: that.data.lat,
        clongitude: that.data.log,
        fitnessName: e.detail.value
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        for (var i = 0; i < res.data.data.length; i++) {
          fitnessdata.push({
            latitude: res.data.data[i].fclatitude,
            longitude: res.data.data[i].fclongitude,
            iconPath: '../../image/fitness_center_1.png',
            width: 50,
            height: 50,
            id: i + 1,
            callout: {
              content: res.data.data[i].fcdefinition + '  ' + res.data.data[i].distance.toFixed(2) + '公里',
              fontSize: 12,
              color: '#ffffff',
              bgColor: '#000000',
              padding: 5,
              borderRadius: 10,
              boxShadow: '4px 8px 16px 0 rgba(0)',
              display: 'BYCLICK'
            }
          })
        }
        that.setData({
          markers: fitnessdata
        })
      }
    })
  }
})