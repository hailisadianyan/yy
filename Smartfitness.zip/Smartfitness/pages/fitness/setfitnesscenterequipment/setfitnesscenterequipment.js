// pages/fitness/setfitnesscenterequipment/setfitnesscenterequipment.js
var app=getApp();
var equimentdata=[];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    details:{},
    arr:[]
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
    var that=this;
    var equipment = [];
    console.log('setfitnesscenterequipment', app.globalData.fitness.equipment)
   
    if (app.globalData.addequipment.length!=0) {
      for (var i = 0; i < app.globalData.addequipment.length;i++){
          equipment.push({
              id: app.globalData.addequipment[i].id,
              local: app.globalData.addequipment[i].local
           })
        }
      }
    // if (app.globalData.addequipment.length ==0 &&app.globalData.editfitnesscenter.length!=0) {
    //   for (var i = 0; i < app.globalData.editfitnesscenter.length; i++) {
    //     equipment.push({
    //       id: app.getStorageSync.editfitnesscenter.emac,
    //       local: app.globalData.editfitnesscenter.fcaddress
    //     })
    //   }
    // }
  
    console.log('输出equipment', equipment, equimentdata)
    that.setData({
      arr: equipment 
    })
    // console.log('arr',this.data.arr)
  // that.getFitnessEquiment();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  addFitnessport:function(){
  
    wx.scanCode({
      success: (res) => {
        console.log(res)
         app.globalData.fitness.Id=res.result
        wx.navigateTo({
          url: '../../fitness/setfitnesscenterport/setfitnesscenterport',
        })
      }
    })
  },
  Equimentcontent:function(e){
    console.log(e)
    var index=e.currentTarget.dataset.id
    var addequipment = app.globalData.addequipment[index].id
    app.globalData.fitness.Id = addequipment  //点击那个健身中心设备进入设备详情
   wx.navigateTo({
     url: '../../fitness/setfitnesscenterport/setfitnesscenterport'
   })
  },
  getFitnessEquiment:function(){
    var that=this
    var eqdata=[];
    wx.request({ //获取健身中心
      url: app.globalData.Url + '/OutdoorFitness/app/user/fitness/authorize/getFitnessCenterEquipment', //接口地址

      data: {  //参数为json格式数据
        fcid: app.globalData.editfitnesscenter.idFitnessCenter
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log('获取健身中心下所有设备',res.data)
       if(res.data.data!=null){
         for(var i=0;i<res.data.data.length;i++){
           eqdata.push({
             id: res.data.data[i].emac,
             local: app.globalData.editfitnesscenter.fcaddress
           })
         }
         that.setData({
           arr: eqdata
         })
        //  equimentdata=equimentdata.concat(eqdata)  ;
         console.log('equimentdata',eqdata)
       }
      
      }
      
    })
   
  }
})