// pages/fitness/setfitnesscenterequipment/setfitnesscenterequipment.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    details:{},
    arr:[ ]
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var equipment=[];

    console.log('setfitnesscenterequipment', app.globalData.fitness.equipment)
   
    if (app.globalData.addequipment.length!=0) {
      for (var i = 0; i < app.globalData.addequipment.length;i++){
          equipment.push({
              id: app.globalData.addequipment[i].id,
              local: app.globalData.addequipment[i].local
           })
        }
      }

    // console.log('equipment',equipment)
    this.setData({
      arr: equipment 
    })
    // console.log('arr',this.data.arr)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  addFitnessport:function(){
  
    wx.scanCode({
      success: (res) => {
        console.log(res)
         app.globalData.fitness.Id=res.result
        wx.navigateTo({
          url: '../../fitness/setfitnesscenterport/setfitnesscenterport',
        })
      }
    })
  },
  Equimentcontent:function(e){
    console.log(e)
    var index=e.currentTarget.dataset.id
    var addequipment = app.globalData.addequipment[index].id
    app.globalData.fitness.Id = addequipment  //点击那个健身中心设备进入设备详情
   wx.navigateTo({
     url: '../../fitness/setfitnesscenterport/setfitnesscenterport'
   })
  }
})