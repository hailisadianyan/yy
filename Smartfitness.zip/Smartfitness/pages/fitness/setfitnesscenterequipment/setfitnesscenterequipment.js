// pages/fitness/setfitnesscenterequipment/setfitnesscenterequipment.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    details:{},
    arr:[{ //arr:[{},{}]
      equipment:{
        id:'3B:30:8D:90',
        local:'广东省深圳市桃花源创新科技园第一分园'
      }},
      {
        equipment: {
          id: '5B:40:9F:99',
          local: '广东省深圳市桃花源创新科技园第二分园'
        }
      }
      ]
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
 console.log(123123);

 console.log(this.data.arr[0])
   console.log(options)
   if(options.id!=undefined){
     this.setData({
       equipmentcontent:options
     })
   }
   console.log(this.data.equipmentcontent)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  addFitnessport:function(){
    var id ="3B:30:8D:90"
    var item = ['三位扭腰器','太空漫步机']
    wx.scanCode({
      success: (res) => {
        console.log(res)
        wx.navigateTo({
          url: '../../fitness/setfitnesscenterport/setfitnesscenterport?result=' + res.result + '&id=' + id + '&items=' +item,
        })
      }
    })
  },
  Equimentcontent:function(e){
    var portindex=e.currentTarget.dataset.id;
    var arr=this.data.arr;
    var Id = arr[portindex].equipment.id
    console.log(portindex)
    console.log(arr[portindex].equipment.id)
   wx.navigateTo({
     url: '../../fitness/setfitnesscenterport/setfitnesscenterport?id='+Id
   })
  }
})