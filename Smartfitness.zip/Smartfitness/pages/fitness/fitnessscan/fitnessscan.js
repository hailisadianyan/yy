// pages/fitness/fitnessscan/fitnessscan.js
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    deviceId:'',
    serviceId:'',
    characteristicId:'',
    Characteristics:[],
    ble:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        console.log(res.result);
        that.setData({
          deviceId:res.result
        })
        that.openBluetoothAdapter();
     
        // wx.showLoading({
        //   title: '建立蓝牙连接...',
        // })
      }
    })
    
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  openBluetoothAdapter:function(){
    var that=this;
    var available=true;
     wx.openBluetoothAdapter({
       success: function(res) {
         console.log('初始化蓝牙适配器成功');
        //  that.startBlue();
         var deviceId = that.data.deviceId
         wx.navigateTo({
           url: '../../fitness/fitnessexercise/fitnessexercise?deviceId=' + deviceId,
         })
       },
       complete:function(){
         wx.getBluetoothAdapterState({
           success: function(res) {
             console.log('getBluetoothAdapterState:',res)
             if(res.available==false){
               available=res.available;
             wx.showToast({
               title: '蓝牙未适配成功，请先打开蓝牙',
               icon:'none',
               duration:3000
             })
              
             wx.onBluetoothAdapterStateChange(function(res){
               console.log('监听蓝牙打开：',res.available)
                 available=res.available

               if(res.available){
                 setTimeout(function(){
                  
                   wx.redirectTo({
                     url: '../../fitness/fitnessexercise/fitnessexercise?deviceId=' + deviceId,
                   })
                 },2000)
               }
             })
             }
           },
         })
       }
       
     })
   
       setTimeout(function(){
         console.log('(available',available )
         if (available == false) {
           wx.navigateBack({
           
          })
         }
       },5000)
     
  },
  // startBlue:function(){
  //   var that=this;
  //  wx.startBluetoothDevicesDiscovery({
  //     services:['00000001-1212-EFDE-1523-785FEABCD123'],
  //    success: function(res) {
  //      console.log('startBluetoothDevicesDiscovery',res)
  //      that.getBuletooth();
  //      that.onBluetooth();
  //    },
  //  })
  // },
  // getBuletooth:function(){
  //   var that = this;
  //   wx.getBluetoothDevices({
  //     success: function(res) {
  //       res.devices.forEach(function(item,index){
  //         var name=item.name;
  //         var isMy=name.indexOf("_");
  //         if(isMy>-1){
  //           that.data.ble.push({
  //             RSSI:item.RSSI,
  //             deviceId:item.deviceId,
  //             name:name.substring(0,isMy),
  //             type:name.substring(isMy+1,name.length)
  //           });
  //           that.setData({
  //             ble:that.data.ble
  //           })
  //         }
  //         // console.log('输出that.data.ble:',that.data.ble)
  //       })
      
  //     },
  //   })
  // },
  // onBluetooth:function(){
  //   var that = this;
 
  //   wx.onBluetoothDeviceFound(function(res){
  //      if(res.devices[0].deviceId==that.data.deviceId){
  //       // a=1;
  //       console.log('找到新设备',res);
  //       console.log('输出res.devices[0].deviceId',res.devices[0].deviceId)
  //       that.createBLE();
  //       console.log('输出that.data.deviceId', that.data.deviceId)
  //     }
 
  //    })
   
  //  },
  // stopSearch:function(){
  //   wx.stopBluetoothDevicesDiscovery({
  //     success: function (res) {
  //       console.log('停止搜索蓝牙：',res)
  //     }
  //   })
  // },
  //  createBLE:function(){ //创建蓝牙连接。如果成功就结束蓝牙搜索
  //    var that=this;
  //    wx.createBLEConnection({
  //      deviceId: that.data.deviceId,
  //      success: function(res) {
  //        console.log('创建蓝牙连接成功：',res)
  //        that.stopSearch();
  //        that.getBLEDeviceServices();
  //      },
  //    })
  //  },
  // getBLEDeviceServices:function(){
  //   var that=this;
  //   wx.getBLEDeviceServices({
  //     deviceId: that.data.deviceId,
  //     success: function(res) {
  //       console.log('device services:', res.services)
  //       that.setData({ services: res.services });
  //       console.log('device services:', that.data.services[1].uuid);
  //       that.setData({ serviceId: that.data.services[1].uuid });
  //       console.log('--------------------------------------');
  //       console.log('device设备的id:', that.data.deviceId);
  //       console.log('device设备的服务id:', that.data.serviceId);
  //      that.getBLEDeviceCharacteristics()
  //     },
  //   })
  // },
  // getBLEDeviceCharacteristics:function(){
  //   var that=this;
  //   wx.getBLEDeviceCharacteristics({
  //     // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
  //     deviceId:that.data.deviceId,
  //     // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
  //     serviceId:that.data.serviceId,
  //     success: function (res) {
  //       var Characteristics=[];
  //       console.log('device getBLEDeviceCharacteristics:', res.characteristics)
  //       for(var i=0;i<res.characteristics.length;i++){
  //         Characteristics.push({
  //           characteristicId:res.characteristics[i].uuid
  //         })
  //       }
  //       that.setData({
  //         Characteristics: Characteristics
  //       })
  //       console.log('获取Characteristics：', Characteristics)
  //       that.notifyBLECharacteristicValueChange();
  //     }
     
  //   })
    
  // },
  // notifyBLECharacteristicValueChange:function(){
  //   var that=this;
  //   wx.notifyBLECharacteristicValueChange({
  //     state: true, // 启用 notify 功能
  //     // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接  
  //     deviceId:that.data.deviceId,
  //     // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
  //     serviceId:that.data.serviceId,
  //     // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
  //     characteristicId: that.data.Characteristics[0].characteristicId,
  //     success: function (res) {
  //       console.log(res)
  //       console.log('notifyBLECharacteristicValueChange success', res.errMsg)
  //       that.onBLECharacteristicValueChange();
  //      if(res.errCode==0){
  //        wx.hideLoading();
  //        app.globalData.scanfitness.status=1
  //        wx.navigateTo({
  //           url: '../../fitness/fitnessexercise/fitnessexercise',
  //         })
  //      }
  //     }
  //   })
  // },
  // onBLECharacteristicValueChange:function(){
  //   var that=this;
  //   wx.onBLECharacteristicValueChange(function (res) {
  //     var result='';
  //     console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
  //     console.log('输出res.value',res.value)
  //     result=res.value;
  //    // console.log('输出ab2hext(res.value)',that.ab2hext(res.value))
  //     var data = that.ab2hex(result).slice(0, 4) == '5501' ?that.ab2hex(result):'';
  //    // console.log('ascdata:', data)
  //     // console.log('数据:', data.slice(6,19))
  //     // console.log('校验码',data.slice(20,26))
  //     var header=data.slice(0,4);
  //     var status=data.slice(4,6);
  //     if(status=='a8'){
  //       var epnumber = data.slice(6, 8);
  //       var fitnessnum = data.slice(8, 12)
  //       var fitnessduration = data.slice(12, 16);
  //       var fitnessconsume = data.slice(16, 20);
  //       var fd = fitnessduration.split('');
  //       var duration = parseInt(fd[0], 16) * 16 + parseInt(fd[1], 16) + parseInt(fd[2], 16) * 16 * 16 * 16 + parseInt(fd[3], 16) * 16 * 16;
  //       var fc = fitnessconsume.split('');
  //       var consume = parseInt(fc[0], 16) * 16 + parseInt(fc[1], 16) + parseInt(fc[2], 16) * 16 * 16 * 16 + parseInt(fc[3], 16) * 16 * 16;
  //       app.globalData.scanfitness.duration = duration;
  //       app.globalData.scanfitness.consume = consume;
  //     }
  //     if(status=='a7'){
  //       console.log('结束了');
  //       app.globalData.scanfitness.status = 2
  //       wx.closeBluetoothAdapter({
  //         success: function (res) {
  //           console.log(res)
  //         }
  //       })
  //     }
     
  //     console.log(app.globalData.scanfitness.duration, app.globalData.scanfitness.consume)
  //   })
  //   wx.onBLEConnectionStateChange(function (res) {
  //     // 该方法回调中可以用于处理连接意外断开等异常情况
  //     console.log(`device ${res.deviceId} state has changed, connected: ${res.connected}`)
  //     that.recreateBLE();
  //   })
  // },
  // ab2hex:function(buffer) {
  //   var hexArr = Array.prototype.map.call(
  //     new Uint8Array(buffer),
  //     function (bit) {
  //       return ('00' + bit.toString(16)).slice(-2)
  //     }
  //   )
  //     return hexArr.join('');
  // },

 


  // recreateBLE: function () { //创建蓝牙连接。如果成功就结束蓝牙搜索
  //   var that = this;
  //   wx.createBLEConnection({
  //     deviceId: that.data.deviceId,
  //     success: function (res) {
  //       that.regetBLEDeviceServices();
  //     },
  //   })
  // },
  // regetBLEDeviceServices: function () {
  //   var that = this;
  //   wx.getBLEDeviceServices({
  //     deviceId: that.data.deviceId,
  //     success: function (res) {
  //       that.setData({ services: res.services });
  //       that.setData({ serviceId: that.data.services[1].uuid });
  //       that.regetBLEDeviceCharacteristics()
  //     },
  //   })
  // },
  // regetBLEDeviceCharacteristics: function () {
  //   var that = this;
  //   wx.getBLEDeviceCharacteristics({
  //     // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
  //     deviceId: that.data.deviceId,
  //     // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
  //     serviceId: that.data.serviceId,
  //     success: function (res) {
  //       var Characteristics = [];
  //       for (var i = 0; i < res.characteristics.length; i++) {
  //         Characteristics.push({
  //           characteristicId: res.characteristics[i].uuid
  //         })
  //       }
  //       that.setData({
  //         Characteristics: Characteristics
  //       })
  //       that.renotifyBLECharacteristicValueChange();
  //     }

  //   })

  // },
  // renotifyBLECharacteristicValueChange: function () {
  //   var that = this;
  //   wx.notifyBLECharacteristicValueChange({
  //     state: true, // 启用 notify 功能
  //     // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接  
  //     deviceId: that.data.deviceId,
  //     // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
  //     serviceId: that.data.serviceId,
  //     // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
  //     characteristicId: that.data.Characteristics[0].characteristicId,
  //     success: function (res) {
  //       that.reonBLECharacteristicValueChange();
  //       // if (res.errCode == 0) {
  //       //   wx.hideLoading();
  //       //   app.globalData.scanfitness.status = 1
  //       //   wx.navigateTo({
  //       //     url: '../../fitness/fitnessexercise/fitnessexercise',
  //       //   })
  //       // }
  //     }
  //   })
  // },
  // reonBLECharacteristicValueChange: function () {
  //   var that = this;
  //   wx.onBLECharacteristicValueChange(function (res) {
  //     var result = '';
  //     // console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
  //     // console.log('输出res.value', res.value)
  //     result = res.value;
  //     var data = that.ab2hex(result).slice(0, 4) == '5501' ? that.ab2hex(result) : '';
  //     var header = data.slice(0, 4);
  //     var status = data.slice(4, 6);
  //     if (status == 'a8') {
  //       var epnumber = data.slice(6, 8);
  //       var fitnessnum = data.slice(8, 12)
  //       var fitnessduration = data.slice(12, 16);
  //       var fitnessconsume = data.slice(16, 20);
  //       var fd = fitnessduration.split('');
  //       var duration = parseInt(fd[0], 16) * 16 + parseInt(fd[1], 16) + parseInt(fd[2], 16) * 16 * 16 * 16 + parseInt(fd[3], 16) * 16 * 16;
  //       var fc = fitnessconsume.split('');
  //       var consume = parseInt(fc[0], 16) * 16 + parseInt(fc[1], 16) + parseInt(fc[2], 16) * 16 * 16 * 16 + parseInt(fc[3], 16) * 16 * 16;
  //       app.globalData.scanfitness.duration = duration;
  //       app.globalData.scanfitness.consume = consume;
  //     }
  //     if (status == 'a7') {
  //       console.log('结束了');
  //       app.globalData.scanfitness.status = 2
  //       wx.closeBluetoothAdapter({
  //         success: function (res) {
  //           console.log(res)
  //         }
  //       })
  //     }

  //     console.log(app.globalData.scanfitness.duration, app.globalData.scanfitness.consume)
  //   })
  //   wx.onBLEConnectionStateChange(function (res) {
  //     console.log(`device ${res.deviceId} state has changed, connected: ${res.connected}`)
  //     that.recreateBLE();
  //   })
  // },
})