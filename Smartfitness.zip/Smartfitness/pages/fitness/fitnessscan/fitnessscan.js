// pages/fitness/fitnessscan/fitnessscan.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    deviceId:'',
    serviceId:'',
    characteristicId:'',
    Characteristics:[],
    ble:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        console.log(res.result);
        that.setData({
          deviceId:res.result
        })
        that.openBluetoothAdapter();
        // wx.navigateTo({
        //   url: '../../fitness/fitnessexercise/fitnessexercise',
        // })
      }
    })
    
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  openBluetoothAdapter:function(){
    var that=this;
     wx.openBluetoothAdapter({
       success: function(res) {
         console.log('初始化蓝牙适配器成功');
         that.startBlue();
       },
       complete:function(){
         wx.getBluetoothAdapterState({
           success: function(res) {
             console.log('getBluetoothAdapterState:',res)
             if(res.available==false){
             wx.showToast({
               title: '蓝牙未适配成功，请先打开蓝牙',
               icon:'none',
               duration:3000
             })
             wx.onBluetoothAdapterStateChange(function(res){
               console.log('监听蓝牙打开：',res.available)
               if(res.available){
                 setTimeout(function(){
                   that.startBlue();
                 },2000)
               }
             })
             }
           },
         })
       }
     })
  },
  startBlue:function(){
    var that=this;
   wx.startBluetoothDevicesDiscovery({
    // services:[this.data.serviceid],
     success: function(res) {
       console.log('startBluetoothDevicesDiscovery',res)
       that.getBuletooth();
       that.onBluetooth();
     },
   })
  },
  getBuletooth:function(){
    var that = this;
    wx.getBluetoothDevices({
      success: function(res) {
        res.devices.forEach(function(item,index){
          var name=item.name;
          var isMy=name.indexOf("_");
          if(isMy>-1){
            that.data.ble.push({
              RSSI:item.RSSI,
              deviceId:item.deviceId,
              name:name.substring(0,isMy),
              type:name.substring(isMy+1,name.length)
            });
            that.setData({
              ble:that.data.ble
            })
          }
        })
        // that.setData({
        //   ble:that.data.ble
        // })
      },
    })
  },
  onBluetooth:function(){
    var that = this;

    wx.onBluetoothDeviceFound(function(res){
      console.log('找到新设备')
      if (res.devices[0].RSSI > -80) {
        console.log(res)
        var name = res.devices[0].name;
        var isMy = name.indexOf("_");
        if (isMy > -1) {
          that.data.ble.push({
            RSSI: res.devices[0].RSSI,
            deviceId: res.devices[0].deviceId,
            name: name.substring(0, isMy),
            type: name.substring(isMy + 1, name.length)
          })
          that.setData({
            ble: that.data.ble
          })
        }
      }
     })
    console.log(that.data.deviceId)
    that.createBLE();
   },
  stopSearch:function(){
    wx.stopBluetoothDevicesDiscovery({
      success: function (res) {
        console.log('停止搜索蓝牙：',res)
      }
    })
  },
   createBLE:function(){
     var that=this;
     wx.createBLEConnection({
       deviceId: that.data.deviceId,
       success: function(res) {
         console.log('创建蓝牙连接成功：',res)
         that.stopSearch();
         that.getBLEDeviceServices();
       },
     })
   },
  getBLEDeviceServices:function(){
    var that=this;
    wx.getBLEDeviceServices({
      deviceId: that.data.deviceId,
      success: function(res) {
        console.log('device services:', res.services)
        that.setData({ services: res.services });
        console.log('device services:', that.data.services[1].uuid);
        that.setData({ serviceId: that.data.services[1].uuid });
        console.log('--------------------------------------');
        console.log('device设备的id:', that.data.deviceId);
        console.log('device设备的服务id:', that.data.serviceId);
       that.getBLEDeviceCharacteristics()
      },
    })
  },
  getBLEDeviceCharacteristics:function(){
    var that=this;
    wx.getBLEDeviceCharacteristics({
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接
      deviceId:that.data.deviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId:that.data.serviceId,
      success: function (res) {
        var Characteristics=[];
        console.log('device getBLEDeviceCharacteristics:', res.characteristics)
        for(var i=0;i<res.characteristics.length;i++){
          Characteristics.push({
            characteristicId:res.characteristics[i].uuid
          })
        }
        that.setData({
          Characteristics: Characteristics
        })
        console.log('获取Characteristics：', Characteristics)
        that.notifyBLECharacteristicValueChange();
      }
     
    })
    
  },
  notifyBLECharacteristicValueChange:function(){
    var that=this;
    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      // 这里的 deviceId 需要已经通过 createBLEConnection 与对应设备建立链接  
      deviceId:that.data.deviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId:that.data.serviceId,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.Characteristics[0].characteristicId,
      success: function (res) {
        console.log(res)
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        that.onBLECharacteristicValueChange();
      }
    })
  },
  onBLECharacteristicValueChange:function(){
    console.log(123);
    function ab2hex(buffer) {
      var hexArr = Array.prototype.map.call(
        new Uint8Array(buffer),
        function (bit) {
          return ('00' + bit.toString(16)).slice(-2)
        }
      )
      return hexArr.join('');
    }
    wx.onBLECharacteristicValueChange(function (res) {
      console.log(`characteristic ${res.characteristicId} has changed, now is ${res.value}`)
      console.log(ab2hext(res.value))
    })
  }
 
})