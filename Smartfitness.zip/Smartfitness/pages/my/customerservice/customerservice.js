// pages/my/customerservice/customerservice.js

Page({
 
  /**
   * 页面的初始数据
   */
  data: {
   status:0,
   sweepcode:'1532543623',
   items: [
     { question: '二维码脱落' },
     { question: '问题二' },
     { question: '问题三' },
     { question: '问题四' },
     { question: '问题五' },
     { question: '问题六' },
     { question: '问题七' },
     { question: '其他' },
   ],
   src:"../../image/camera.png",
   radiochoose:'',
   questioncontent:'',
   disabled:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
       // wx.request({ //获取问题列表
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
          // 'pageNum':1,
          //  'pageSize':5

    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })


 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
   
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
 
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
   
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Sweep:function(){
    var that=this;
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        // console.log(res)
        that.setData({
          status:1
        })
      }
    })
 
 
  },
  radioChange: function (e) {
    // console.log('radio发生change事件，携带value值为：', e.detail.value)
    this.setData({
      radiochoose: e.detail.value
    })
  },
 ChooseImage:function(){
   var that=this;
   wx.chooseImage({
     count: 1, // 默认9
     sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
     sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
     success: function (res) {
       // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
       var tempFilePaths = res.tempFilePaths
        that.setData({
          src: tempFilePaths
        })
     }
   })
 },
 bindTextAreaBlur: function (e) {
  this.setData({
    questioncontent: e.detail.value
  })
  console.log(this.data.status);
  console.log(this.data.radiochoose);
  console.log(this.data.questioncontent);
  if (this.data.questioncontent) {
    this.setData({
      disabled: false
    })
  }
 },


 questionsubmit:function(){
   wx.showToast({
     title: '提交成功',
   })
       // wx.request({ //提交问题反馈
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
          // 'pageNum':1,
          //  'pageSize':5

    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
 }

})