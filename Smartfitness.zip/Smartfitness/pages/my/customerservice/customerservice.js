// pages/my/customerservice/customerservice.js
var app=getApp();
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
   status:0,
   sweepcode:'',
   items: [
   ],
   src:"../../image/camera.png",
   radiochoose:'',
   questioncontent:'',
   disabled:true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   var that=this;
       wx.request({ //获取问题列表
         url:app.globalData.Url+'/OutdoorFitness/app/user/getQuestions', //接口地址
      data: {          //参数为json格式数据
        
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token')
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)
        that.setData({
          items:res.data.data
        })
        console.log(that.data.items)
      }
      
    })


 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
   
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
 
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
   
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Sweep:function(){
    var that=this;
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
         console.log(res)
        that.setData({
          status:1,
          sweepcode:res.result
        })
      }
    })
 
 
  },
  radioChange: function (e) {
    console.log(e)
    // console.log('radio发生change事件，携带value值为：', e.detail.value)
    this.setData({
      radiochoose: e.detail.value
    })
  },
 ChooseImage:function(){
   var that=this;
   wx.chooseImage({
     count: 1, // 默认9
     sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
     sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
     success: function (res) {
       // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
       var tempFilePaths = res.tempFilePaths
        that.setData({
          src: tempFilePaths
        })
        // wx.uploadFile({
        //   url:app.globalData.Url+'/OutdoorFitness/app/user/addImg', //仅为示例，非真实的接口地址
        //   filePath: tempFilePaths[0],
        //   name: 'file',
        //    header: {
        //      'content-type': 'application/json',
        //      'Accept': 'application/json',
        //      'token': wx.getStorageSync('token')
        //    },
        //   success: function (res) {
        //     var data = res.data
        //     //do something
        //   }
        // })
     }
   })
 },
 bindTextAreaBlur: function (e) {
  this.setData({
    questioncontent: e.detail.value
  })

  console.log(this.data.questioncontent);
  if (this.data.questioncontent) {
    this.setData({
      disabled: false
    })
  }
 },


 questionsubmit:function(){
   wx.showToast({
     title: '提交成功',
   })
   var that = this;
  //  wx.request({ //获取问题列表
  //    url: app.globalData.Url + '/OutdoorFitness/app/user/addFeedback', //接口地址
  //    data: {          //参数为json格式数据
  //      fcontent: that.data.questioncontent,
  //      mac: that.data.sweepcode,
  //      qid: that.data.radiochoose
  //    },
  //    header: {
  //      'content-type': 'application/json',
  //      'Accept': 'application/json',
  //      'token': wx.getStorageSync('token')
  //    },
  //    method: 'POST',
  //    success: function (res) {
  //      console.log(res.data)
       
  //    }

  //  })
 }

})