// pages/my/myuserinfo/myuserinfo.js
var app=getApp();
var time = require('../../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    headportraitUrl:'',
    nickname:'',
    phonenum:'',
    gender:'',
    birthday:'',
    height:'',
    weight:'',
    sosphone:'',
    userinfo:[],
    uopenid: '',
    defaultImg:'../../image/leftbar_info.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;

      wx.request({ //获取用户个人信息
        url: app.globalData.Url +'/OutdoorFitness/app/user/getAppUserData', //接口地址
      data: {          //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token')
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)
        var userdata=[];
        var phone = res.data.data.uphone; //获取手机号
        var sosPhone=res.data.data.usosPhone;//获取sosphone
        var birthday = res.data.data.ubirthday;//获取生日毫秒数
        var uphone =res.data.data.uphone; //设置中间四位为*号
        var Img = res.data.data.uimg.slice(0, 4) == 'http' ? res.data.data.uimg : app.globalData.Url + '/image' + res.data.data.uimg
        var ubirthday = time.formatTimeTwo(birthday) //利用毫秒数求日期
        if (res.data.data.ugender==null){
          res.data.data.ugender='';
        }
        if (res.data.data.uweight == null) {
          res.data.data.uweight = 0;
        }
        if (res.data.data.uheight == null) {
          res.data.data.uheight= 0;
        }
        if (sosPhone == null) {
          sosPhone = '';
        }

           userdata.push({ //设置userdata的数据
             uage:"",
             nickname: res.data.data.unickname,
             phonenum: res.data.data.uphone,
             gender: res.data.data.ugender,
             birthday: ubirthday,
             height: res.data.data.uheight,
             weight: res.data.data.uweight,
             sosphone: sosPhone,
             isAuthorize: res.data.data.isAuthorize,
             uopenid: res.data.data.uopenid,
             headportraitUrl:Img
           })
        
         that.setData({ //设置data数据
           nickname:res.data.data.unickname,
           phonenum: uphone,
           gender:res.data.data.ugender,
           birthday: ubirthday,
           height: res.data.data.uheight,
           weight: res.data.data.uweight,
           sosphone: sosPhone ,
           userinfo:userdata,
           uopenid: res.data.data.uopenid,
           headportraitUrl: Img 
         })
       
        app.globalData.UserInfo = that.data.userinfo //将userinfo设置为全局变量
      },
      fail:function(){
        wx.showToast({
          title: '网络错误',
          icon:'none'
        })
      }
    })
     
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
   
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  uploadPhoto:function() {
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    })
  },
 upload:function(page, path) {//上传图片
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }),
    wx.uploadFile({
      url: app.globalData.Url + "/OutdoorFitness/app/user/doUploadUserImg",
      filePath: path[0],
      name: 'file',
      header: { 
        "Content-Type": "multipart/form-data",
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
        },
      success: function (res) {
        console.log(res);
        if (res.statusCode != 200) {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          })
          return;
        }
        var data = res.data
        page.setData({  //上传成功修改显示头像
          headportraitUrl: path[0]
        })
      },
      fail: function (e) {
        console.log(e);
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        })
      },
      complete: function () {
        wx.hideToast();  //隐藏Toast
      }
    })
  },
  nickName:function(){
   
   wx.navigateTo({
     url: '../../my/modifynickname/modifynickname',
   }) 
  },
  Gender:function(){
  wx.navigateTo({
    url: '../../my/modifygender/modifygender',
  })
  },
  Birthday:function(){
   wx.navigateTo({
     url: '../../my/modifybirthday/modifybirthday',
   })
  },
  Height:function(){
    wx.navigateTo({
      url: '../../my/modifyheight/modifyheight',
    })
  },

  Weight:function(){
    wx.navigateTo({
      url: '../../my/modifyweight/modifyweight',
    })
  },
  sosPhone:function(){
  wx.navigateTo({
    url: '../../my/modifysosphone/modifysosphone',
  })
  },
  Exit:function(){
    wx.showModal({
      title: '确认退出登录？',
      content: '',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.removeStorage({
            key: 'token',
            success: function (res) {
              console.log(res.data)
            }
          })
          wx.navigateTo({
            url: '../../loginregister/login/login',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  errorFunction: function (e) { //当获取的图片无法加载时，加载默认图片

    console.log(e)
    // var errorImgIndex = e.target.dataset.index //获取循环的下标
    // var imgObject = "guidance[" + errorImgIndex + "].Src" //guidance为数据源，对象数组
    // var errorImg = {}
    // errorImg[imgObject] = this.data.defaultImg //我们构建一个对象
    // this.setData(errorImg) //修改数据源对应的数据
    this.setData({

      headportraitUrl: this.data.defaultImg
    })

  }
})