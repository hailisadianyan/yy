// pages/my/myuserinfo/myuserinfo.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    headportraitUrl:'../../image/leftbar_info.png',
    nickname:'大黄蜂',
    phonenum:'15348303523',
    gender:'男',
    birthday:'1993-12-3',
    height:'180',
    weight:'80',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var phone = this.data.phonenum;
    var mphone = phone.substr(0, 3) + '****' + phone.substr(7);
    this.setData({
      phonenum: mphone
    })
      // wx.request({ //获取用户个人信息
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  uploadPhoto:function() {
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        upload(that, tempFilePaths);
      }
    })
  },
//  upload:function(page, path) {
//     wx.showToast({
//       icon: "loading",
//       title: "正在上传"
//     }),
//     wx.uploadFile({
//       url: constant.SERVER_URL + "/FileUploadServlet",
//       filePath: path[0],
//       name: 'file',
//       header: { "Content-Type": "multipart/form-data" },
//       formData: {
//         //和服务器约定的token, 一般也可以放在header中
//         'session_token': wx.getStorageSync('session_token')
//       },
//       success: function (res) {
//         console.log(res);
//         if (res.statusCode != 200) {
//           wx.showModal({
//             title: '提示',
//             content: '上传失败',
//             showCancel: false
//           })
//           return;
//         }
//         var data = res.data
//         page.setData({  //上传成功修改显示头像
//           src: path[0]
//         })
//       },
//       fail: function (e) {
//         console.log(e);
//         wx.showModal({
//           title: '提示',
//           content: '上传失败',
//           showCancel: false
//         })
//       },
//       complete: function () {
//         wx.hideToast();  //隐藏Toast
//       }
//     })
//   },
  nickName:function(){
   wx.navigateTo({
     url: '../../my/modifynickname/modifynickname',
   }) 
  },
  Gender:function(){
  wx.navigateTo({
    url: '../../my/modifygender/modifygender',
  })
  },
  Birthday:function(){
   wx.navigateTo({
     url: '../../my/modifybirthday/modifybirthday',
   })
  },
  Height:function(){
    wx.navigateTo({
      url: '../../my/modifyheight/modifyheight',
    })
  },

  Weight:function(){
    wx.navigateTo({
      url: '../../my/modifyweight/modifyweight',
    })
  },
  Exit:function(){
    wx.showModal({
      title: '确认退出登录？',
      content: '',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.clearStorage();
          wx.navigateTo({
            url: '../../loginregister/login/login',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }
})