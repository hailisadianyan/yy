// pages/my/fitnessguidance/fitnessguidance.js
var app=getApp();
var pagenum=1;
var list = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
   guidance:[
   ],
   token:'',
   pagenum:'',
   lastPage:'',
   scrollHeight:'',
   defaultImg:'../../image/app_icon.png',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
  


    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          scrollHeight: res.windowHeight
        });
      }
    });
      wx.request({ //获取健康指导
        url: app.globalData.Url + '/OutdoorFitness/app/user/getHealthyGuidances', //接口地址
      data: {          //参数为json格式数据
          'pageNum':pagenum,
           'pageSize':10
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token')
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)

     
        for(var i=0;i<res.data.data.list.length;i++){
          list.push({
            Src:app.globalData.Url+'/image'+res.data.data.list[i].hgimg,
            Title: res.data.data.list[i].hgtitle,
            Content: res.data.data.list[i].hgccontent,
            eptid:res.data.data.list[i].eptid,
            idHealthyGuidance: res.data.data.list[i].idHealthyGuidance
        })
       
        }
        that.setData({
          guidance:list,
          lastPage: res.data.data.lastPage,
          pagenum: res.data.data.firstPage,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
   console.log(1)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    var lastpage=this.data.lastPage;
 
    if (pagenum <= lastpage) {
      this.onLoad();
     pagenum=pagenum+1;
    
    } else if (pagenum >lastpage) {
     wx.showToast({
       title: '到底了，已经没有内容了',
       icon:'none'
     })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  fitnessGuidance:function(e){
    var index=e.currentTarget.dataset.index;
    var title = this.data.guidance[index].Title;
    var src = this.data.guidance[index].Src;
    var idHealthyGuidance = e.currentTarget.dataset.id;
    console.log(idHealthyGuidance)
  
    wx.navigateTo({
      url: '../../my/articledetails/articledetails?title=' + title + '&idHealthyGuidance=' + idHealthyGuidance+'&src='+src,
    })
    
  },
  errorFunction: function (e) { //当获取的图片无法加载时，加载默认图片
    console.log(this.data.guidance) 
   console.log(e)
      var errorImgIndex = e.target.dataset.index //获取循环的下标
      var imgObject = "guidance[" + errorImgIndex + "].Src" //guidance为数据源，对象数组
      var errorImg = {}
      errorImg[imgObject] = this.data.defaultImg //我们构建一个对象
      this.setData(errorImg) //修改数据源对应的数据
 
  }
})