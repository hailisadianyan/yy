// pages/my/fitnessguidance/fitnessguidance.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
   guidance:[
     {
       Src:'../../image/1.jpg',
       Title:'仰卧起坐的好处 这样做更容易减肚子',
       Content: '通过仰卧起坐我们也能够锻炼自己的腹肌，能够更好的控制自己的身体，因为腹肌属于核心肌群，对于稳定身体有很重要的作用，而且腹肌的强壮对背部有较好的支撑作用，使锻炼者在从事其他有氧运动和娱乐活动中增加体力。仰卧起坐也能减肥，但需要每次慢起做150个以上才能燃烧脂肪，否则只能锻炼腹肌，未免太辛苦，而且效果也不理想，长时间做会对脊椎造成伤害。'
     },
     {
       Src: '../../image/2.jpg',
       Title: '标题',
       Content: '仰卧起坐是针对练腹部的人群，通过不断地伸腹卷腹，从而不断的锻炼腹部肌肉，最终达到塑型效果'
     },
     {
       Src: '../../image/3.jpg',
       Title: '标题',
       Content: '仰卧起坐是针对练腹部的人群，通过不断地伸腹卷腹，从而不断的锻炼腹部肌肉，最终达到塑型效果'
     }
   ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      // wx.request({ //获取健康指导
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
          // 'pageNum':1,
          //  'pageSize':5
       
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  fitnessGuidance:function(e){
    var index=e.currentTarget.dataset.index;
    var title = this.data.guidance[index].Title;
    var src = this.data.guidance[index].Src;
    var content = this.data.guidance[index].Content;
    console.log(title);
    console.log(content);
    wx.navigateTo({
      url: '../../my/articledetails/articledetails?title='+title+'&content='+content+'&src='+src,
    })
    
  }
})