// pages/my/ceshi/ceshi.js
var app=getApp();
var a = 2312;
var b = 2312;
var interval='';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    step:0,
    countsetp:'',
    calories:[
      {num:0,date:'08/01'},
      { num:0, date: '08/02' },
      { num: 0, date: '08/03' },
      { num: 0, date: '08/04' }
    ],
    encryptedData: '',
    iv:'',
    a:0.231,
    b:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  var that=this;
  //that.wechatlogin();
   var c=that.data.a
   if(c>1){
     that.setData({
       b:c.toFixed(0)
     })
   }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    that.wechatlogin();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
   wechatlogin: function () {
    var that = this;
    wx.showLoading({
      title: '加载中...',
    })
    wx.login({
      success: function (res) {
        console.log(res)
        var code = res.code;
       
          if (res.code) {
            wx.request({
              url: 'https://api.weixin.qq.com/sns/jscode2session',
              data: {
                appid: app.globalData.APPID,
                secret: app.globalData.SECRET,
                js_code: code,
                grant_type: 'authorization_code'
              },
              header: {
                'content-type': 'application/json'
              },
              success: function (res) {
                // console.log(res)
                var openid = res.data.openid //返回openid
                var sessionkey = res.data.session_key
                app.globalData.openid = openid
                app.globalData.sessionkey = sessionkey
                wx.getWeRunData({
                  success(res) {
                 
                    // console.log(res)
                     that.setData({
                       encryptedData:res.encryptedData,
                       iv:res.iv
                       
                     })
                    wx.hideLoading()
                    app.globalData.encryptedData=res.encryptedData;
                    app.globalData.iv= res.iv;
                    that.getTime(res.encryptedData,res.iv)
                  }
                })
              }
            
            })
           
          }

      }
     })
  },
  Start:function(){
    var that=this;

    interval = setInterval(that.onReady, 10000); //启动,func不能使用括号
    console.log(that.data.encryptedData,that.data.iv)
    that.getTimeTwo();
  },
  End:function(){
    clearInterval(interval);
  },
  getTime: function (a,b){
  
    var that = this;
      that.setData({
      setp:0
    })
    var encryptedData =a;
    var iv=b;
   
    wx.request({ //获取SOSNumber
      url: app.globalData.Url + '/OutdoorFitness/wx/WxController/wxDecrypt', //接口地址

      data: {  //参数为json格式数据
        appId: app.globalData.APPID,
        sessionKey:app.globalData.sessionkey,
        encryptedData: encryptedData,
        iv:iv
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
       // console.log(res)
        console.log(res.data.data.stepInfoList[30])
        var step = res.data.data.stepInfoList[30].step-that.data.countstep
        console.log(step)
        if (isNaN(step)){
          that.setData({
            step:0
          })
        }else{
        that.setData({
          step:step/1
        })
        }
      }
    })
  },
  getTimeTwo: function () {
    var that = this;
    var encryptedData = that.data.encryptedData;
    var iv = that.data.iv;
    console.log('ab:', app.globalData.iv, app.globalData.encryptedData)
    wx.request({ //获取SOSNumber
      url: app.globalData.Url + '/OutdoorFitness/wx/WxController/wxDecrypt', //接口地址

      data: {  //参数为json格式数据
        appId: app.globalData.APPID,
        sessionKey: app.globalData.sessionkey,
        encryptedData: encryptedData,
        iv: iv
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
         console.log(res)
       if(res.data.code==1000){
         console.log(res.data)
         that.setData({
           countstep: res.data.data.stepInfoList[30].step,

         })
       }
       if(res.data.code==1001){
         console.log('解析失败')
       }
      
      }
    })
  }
})