// pages/my/myhealthdata/myhealthdata.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    BMI:18.4,
    evaluation:'',
    info:'偏瘦<18.5 正常18.5-23.9 超重≥24 偏胖24~27.9 肥胖≥28',
    runningdegree :80,
    fintessdegree :65,
    runningdistance:'30.00',
    fitnesstime:'20:00:00',
    a:6
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var coeff = this.data.BMI;
    console.log(coeff);
    var evalua='';
      if(coeff<18.5){
      
          evalua='偏瘦'
          this.setData({
            evaluation: evalua
          }) 
          console.log(this.data.evaluation) 
      }else if(coeff>=18.5&&coeff<24){
          evalua='正常'
          this.setData({
            evaluation: evalua
          }) 
          console.log(this.data.evaluation) 
       }else if(coeff>=24&&coeff<28){
      
          evalua='偏胖'
          this.setData({
            evaluation: evalua
          }) 
          console.log(this.data.evaluation) 
      }else if(coeff>=28.0){
          evalua='肥胖'
            this.setData({
           evaluation:evalua
           }) 
            console.log(this.data.evaluation) 
      };
  
   // wx.request({ //获取用户目标/推荐运动量
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    var running = wx.createCanvasContext('canvasRunning');//创建跑步完成进度并返回绘图上下文context对象。
    running.setLineWidth(8);
    running.setStrokeStyle('#dddddd');
    running.setLineCap('round')
    running.beginPath();//开始一个新的路径
    running.arc(106, 106, 70, 0, 2 * Math.PI, false);//设置一个原点(106,106)，半径为70的圆的路径到当前路径
    running.stroke();//对当前路径进行描边

    running.setLineWidth(8);
    running.setStrokeStyle('#1BEAEA');
    running.setLineCap('round')
    running.beginPath();//开始一个新的路径
    running.arc(106, 106, 70, -Math.PI * 1 / 2, 1.5 * Math.PI * (this.data.runningdegree/100).toFixed(2), false);
    running.stroke();//对当前路径进行描边

    running.draw(); 

    var fitness = wx.createCanvasContext('canvasFiness');//创建健身完成进度并返回绘图上下文context对象。
    fitness.setLineWidth(8);
    fitness.setStrokeStyle('#d2d2d2');
    fitness.setLineCap('round')
    fitness.beginPath();//开始一个新的路径
    fitness.arc(106, 106, 70, 0, 2 * Math.PI, false);//设置一个原点(106,106)，半径为70的圆的路径到当前路径
    fitness.stroke();//对当前路径进行描边

    fitness.setLineWidth(8);
    fitness.setStrokeStyle('#1BEAEA');
    fitness.setLineCap('round')
    fitness.beginPath();//开始一个新的路径
    fitness.arc(106, 106, 70, -Math.PI * 1 / 2, 1.5*Math.PI * (this.data.fintessdegree / 100).toFixed(2), false);
    fitness.stroke();//对当前路径进行描边

    fitness.draw(); 
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  amountExercise:function(){
    wx.navigateTo({
      url: '../../my/setamountexercise/setamountexercise',
    })
  }
})