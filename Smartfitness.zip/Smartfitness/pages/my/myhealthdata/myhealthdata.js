// pages/my/myhealthdata/myhealthdata.js
var time = require('../../../utils/util.js');
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    BMI:'',
    evaluation:'',
    info:'偏瘦<18.5 正常18.5-23.9 超重≥24 偏胖24~27.9 肥胖≥28',
    runningdegree :'',
    fitnessdegree :'',
    runningdistance:'',
    fitnesstime:'',
    running:'',
    fitness:'',
    a:6
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var runningdegree;
    var fitnessdegree;
     var htfitness;
      wx.request({ //获取用户目标/推荐运动量
        url: app.globalData.Url + '/OutdoorFitness/app/user/getExerciseVolume', //接口地址
        data: {          //参数为json格式数据

        },
        header: {
          'content-type': 'application/json',
          'Accept': 'application/json',
          'token': wx.getStorageSync('token')
        },
        method: 'POST',
        success: function (res) {
          console.log(res.data)
        htfitness= time.SecondToDate(res.data.data.htfitness)
         runningdegree = (res.data.data.runDistance / res.data.data.htrun).toFixed(2)
         fitnessdegree = (res.data.data.fitnessTims / res.data.data.htfitness).toFixed(2)
         console.log('runningdegree', runningdegree);
         console.log('fintessdegree',fitnessdegree );
         that.setData({
          BMI:(res.data.data.htbmi).toFixed(1),
          fitnesstime: htfitness,
          runningdistance: res.data.data.htrun,
          runningdegree:Math.ceil(runningdegree*100),
          fitnessdegree: Math.ceil(fitnessdegree*100),
          running: runningdegree,
          fintess: fitnessdegree
         })
         that.BMI(that.data.BMI) //调用BMI是否正常的函数


         var cxt_arc = wx.createCanvasContext('canvasRunning');//创建并返回绘图上下文context对象。
         cxt_arc.setLineWidth(8);
         cxt_arc.setStrokeStyle('#d2d2d2');
         cxt_arc.setLineCap('round')
         cxt_arc.beginPath();//开始一个新的路径
         cxt_arc.arc(106, 106, 70, 0, 2 * Math.PI, false);//设置一个原点(106,106)，半径为100的圆的路径到当前路径
         cxt_arc.stroke();//对当前路径进行描边

         cxt_arc.setLineWidth(8);
         cxt_arc.setStrokeStyle('#1BEAEA');
         cxt_arc.setLineCap('round')
         cxt_arc.beginPath();//开始一个新的路径
         cxt_arc.arc(106, 106, 70, -Math.PI / 2, 2 * runningdegree * Math.PI - Math.PI / 2, false);
         cxt_arc.stroke();//对当前路径进行描边
         console.log(runningdegree)
         cxt_arc.draw();


         var fitness = wx.createCanvasContext('canvasFiness');//创建健身完成进度并返回绘图上下文context对象。
         fitness.setLineWidth(8);
         fitness.setStrokeStyle('#d2d2d2');
         fitness.setLineCap('round')
         fitness.beginPath();//开始一个新的路径
         fitness.arc(106, 106, 70, 0, 2 * Math.PI, false);//设置一个原点(106,106)，半径为70的圆的路径到当前路径
         fitness.stroke();//对当前路径进行描边

         fitness.setLineWidth(8);
         fitness.setStrokeStyle('#1BEAEA');
         fitness.setLineCap('round')
         fitness.beginPath();//开始一个新的路径
         fitness.arc(106, 106, 70, -Math.PI / 2, 2 * fitnessdegree * Math.PI - Math.PI / 2, false);
         fitness.stroke();//对当前路径进行描边
         console.log(runningdegree)
         fitness.draw(); 


        }
      })
    

   
      

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    // 页面渲染完成
    this.onLoad();

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  amountExercise:function(){
  
    wx.navigateTo({
      url: '../../my/setamountexercise/setamountexercise',
    })
  },
  BMI:function(bmi){
    var that=this;
    var coeff = bmi;
    var evalua = '';
    if (coeff < 18.5) {

      evalua = '偏瘦'
      that.setData({
        evaluation: evalua
      })
      console.log(that.data.evaluation)
    } else if (coeff >= 18.5 && coeff < 24) {
      evalua = '正常'
      that.setData({
        evaluation: evalua
      })
      console.log(that.data.evaluation)
    } else if (coeff >= 24 && coeff < 28) {

      evalua = '偏胖'
      that.setData({
        evaluation: evalua
      })
      console.log(that.data.evaluation)
    } else if (coeff >= 28.0) {
      evalua = '肥胖'
      that.setData({
        evaluation: evalua
      })
    };

  }
})