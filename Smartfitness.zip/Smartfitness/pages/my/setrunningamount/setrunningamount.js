// pages/my/setrunningamount/setrunningamount.js
var hundredbit = []
var tenbit = []
var bits = []

for (let i = 0; i <= 9; i++) {
  hundredbit.push(i)
}

for (let i = 0; i <= 9; i++) {
  tenbit.push(i)
}

for (let i = 0; i <= 9; i++) {
  bits.push(i)
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showDialog: false,
    hundredbit: hundredbit,
    tenbit: tenbit,
    bits: bits,
    running: 30
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this

    that.setData({
      value: 'show'
    });
      // wx.request({ //获取用户目标/推荐运动量
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  toggleDialog() {
    this.setData({
      showDialog: !this.data.showDialog
    });
  },
  freeBack: function () {
    var that = this
    that.setData({
      showDialog: !this.data.showDialog
    })
  },
  freetoBack: function () {
    var that = this
    that.setData({
      showDialog: !this.data.showDialog,
    })
  },
  bindChange: function (e) {
    const val = e.detail.value;
    var hundredbit = this.data.hundredbit[val[0]];
    var tenbit = this.data.tenbit[val[1]];
    var bits = this.data.bits[val[2]];
    var running = hundredbit * 100 + tenbit * 10 + bits;
    this.setData({
      running: running
    })

  },
  setRunningamount:function(){
    // wx.request({ //设置用户目标/推荐运动量
    //   url: 'https://www.sjxty.net/OutdoorFitness/app/user/getAppUserData', //接口地址
    //   data: {          //参数为json格式数据
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded',
    //     'Accept': 'application/json'
    //   },
    //   method:'POST',
    //   success: function (res) {
    //     console.log(res.data)
    //   }
    // })
  }
})