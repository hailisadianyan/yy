// pages/my/modifygender/modifygender.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
   gender:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    console.log(app.globalData.UserInfo)
    that.setData({
      gender: app.globalData.UserInfo[0].gender
    })
 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  selectMale:function(e){
    this.setData({
      gender:e.currentTarget.dataset.value
    })
  },
  selectFamale:function(e){
    this.setData({
      gender: e.currentTarget.dataset.value
    })
  },
  modifyGender:function(){
    wx.request({
      url: app.globalData.Url + '/OutdoorFitness/app/user/doUpdateUserDatas', //接口地址
      data: {  //参数为json格式数据
        uage: app.globalData.UserInfo[0].uage,
        uphone: app.globalData.UserInfo[0].phonenum,
        unickname: app.globalData.UserInfo[0].nickname,
        ugender:this.data.gender,
        ubirthday: app.globalData.UserInfo[0].birthday,
        uheight: app.globalData.UserInfo[0].height,
        uweight: app.globalData.UserInfo[0].weight,
        usosPhone: app.globalData.UserInfo[0].sosphone,
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        if (res.data.code == 1000) {
          wx.showToast({
            title: '设置成功',
            icon: 'success',
            duration: 2000,
            success: function () {
              wx.navigateBack({
                delta: 1
              })
            }
          })

        } else if (res.data.code == 1001) {
          wx.showToast({
            title: '设置失败',
            icon: 'none',
            duration: 2000
          })
        }
      }
    })
  }
})