  // pages/my/setfitnessamount/setfitnessamount.js
  var app=getApp()
var hundredbit = []
var tenbit = []
var bits = []

for (let i = 0; i <= 240; i++) {
  hundredbit.push(i)
}

for (let i = 0; i <= 59; i++) {
  tenbit.push(i)
}

for (let i = 0; i <= 59; i++) {
  bits.push(i)
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showDialog: false,
    hundredbit: hundredbit,
    tenbit: tenbit,
    bits: bits,
   fitness: '',
   fitnesstime:'',
   running:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this

    that.setData({
      value: 'show',
    });
    wx.request({ //获取用户目标/推荐运动量
      url: app.globalData.Url + '/OutdoorFitness/app/user/getExerciseVolume', //接口地址
      data: {          //参数为json格式数据

      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        var num = res.data.data.htfitness;
        var a = parseInt(num / 3600)
        var b = parseInt(num % 3600 / 60)
        var c = parseInt(num % 60)
        var d = []
        d.push(a, b, c)
        that.setData({
          running: res.data.data.htrun,
          fitness: (res.data.data.htfitness / 3600).toFixed(1),
          fitnesstime: res.data.data.htfitness,
          value:d
        })

      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  toggleDialog() {
    this.setData({
      showDialog: !this.data.showDialog
    });
  },
  freeBack: function () {
    var that = this
    that.setData({
      showDialog: !this.data.showDialog
    })
  },
  freetoBack: function () {
    var that = this
    that.setData({
      showDialog: !this.data.showDialog,
    })
  },
  bindChange: function (e) {
    const val = e.detail.value;
    var hour = this.data.hundredbit[val[0]];
    var min = this.data.tenbit[val[1]];
    var second = this.data.bits[val[2]];
    var fitness = ((hour * 3600 + min * 60 + second)/3600).toFixed(1);
    var fitnesstime =hour * 3600 + min * 60 + second
    this.setData({
      fitness: fitness,
      fitnesstime: fitnesstime
    })

  },
  setFitnessamount:function(){
    var that=this;
       wx.request({ //获取用户目标/推荐运动量
      url: app.globalData.Url+ '/OutdoorFitness/app/user/updateExerciseVolume', //接口地址
      data: {  //参数为json格式数据
        htfitness:that.data.fitnesstime,
        htrun: that.data.running
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token')
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)
        if (res.data.code) {
          wx.showToast({
            title: '设置成功',
  
          })
          // wx.redirectTo({
          //   url: '../../my/setamountexercise/setamountexercise'
          // })
          wx.navigateBack({
            delta:1
          })
        }
      }
    })
  }
})