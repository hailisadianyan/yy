// pages/my/repair/repair.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    items: [],
    src: "../../image/camera.png",
    radiochoose: '',
    questioncontent: '',
    disabled: true,
    questionImg: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;


       wx.request({ //获取问题列表
         url:app.globalData.Url+'/OutdoorFitness/app/user/getQuestions', //接口地址
      data: {          //参数为json格式数据

      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token':wx.getStorageSync('token')
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)
        that.setData({
          items:res.data.data
        })
        console.log(that.data.items)
      }

    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   this.btn();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
    radioChange: function (e) {
    console.log(e)
    // console.log('radio发生change事件，携带value值为：', e.detail.value)
    this.setData({
      radiochoose: e.detail.value
    })
  },

  ChooseImage: function () {
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        that.upload(that, tempFilePaths);
      }
    })
  },
  upload: function (page, path) {//上传图片
  var that=this;
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    }),
      wx.uploadFile({
        url: app.globalData.Url + "/OutdoorFitness/app/user/addImg",
        filePath: path[0],
        name: 'file',
        header: {
          "Content-Type": "multipart/form-data",
          'Accept': 'application/json',
          'token': wx.getStorageSync('token')
        },
        success: function (res) {
          wx.hideToast();
          console.log(JSON.parse(res.data))
          var data = JSON.parse(res.data)
          that.setData({
            questionImg:data.data
          })
          if (res.statusCode != 200) {
            wx.showModal({
              title: '提示',
              content: '上传失败',
              showCancel: false
            })
            return;
          }
          var data = res.data
          page.setData({  //上传成功修改显示头像
            src: path[0],
          })
        },
        fail: function (e) {
          console.log(e);
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          })
        },
        complete: function () {
          // wx.hideToast();  //隐藏Toast
        }
      })
  },




 bindTextAreaBlur: function (e) {
  this.setData({
    questioncontent: e.detail.value
  })

 },
 btn:function(){
  var that = this;
  console.log(that.data.radiochoose)
  console.log(that.data.questioncontent)
  console.log(that.data.questionImg)

  if ( that.data.radiochoose !== '' || that.data.questioncontent!=='' ||that.data.questionImg!==''){
    this.setData({
      disabled: false
    })
  }
},
 questionsubmit:function(){
    var that = this;

   wx.showToast({
     icon: "loading",
     title: "正在提交"
   });

   wx.request({ //提交用户反馈
     url: app.globalData.Url + '/OutdoorFitness/app/user/addFeedback', //接口地址
     data: {          //参数为json格式数据
       fcontent: that.data.questioncontent,
       mac:  app.globalData.servicemac,
       qid: that.data.radiochoose,
       fimg:that.data.questionImg
     },
     header: {
       'content-type': 'application/json',
       'Accept': 'application/json',
       'token': wx.getStorageSync('token')
     },
     method: 'POST',
     success: function (res) {
       console.log(res.data)
       wx.hideToast()
       if(res.data.code==1000){
         wx.showToast({
           title: '提交成功',
         })
         setTimeout(that.BacK,1000)

       }

     }

   })
 },
 BacK:function(){
   wx.navigateBack({
     delta: 5
   })
 }
})