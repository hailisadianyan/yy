// pages/my/myhomepage/myhomepage.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
   phonenum:'',
   name:'',
    uopenid:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  var that=this;
    wx.request({ //获取用户个人信息
      url: app.globalData.Url + '/OutdoorFitness/app/user/getAppUserData', //接口地址
      data: {          //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        var phone = res.data.data.uphone; //获取手机号
        // var uphone = phone.substr(0, 3) + '****' + phone.substr(7); //设置中间四位为*号
        that.setData({ //设置data数据
          name: res.data.data.unickname,
          phonenum: phone,
          uopenid: res.data.data.uopenid
        })
      },
      fail: function () {
        wx.showToast({
          title: '服务器错误，无法连接服务器',
          icon: 'none'
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  UserInfo:function(){
    wx.navigateTo({
      url: '../../my/myuserinfo/myuserinfo',
    })
  },
  myHealthdata:function(){
   wx.navigateTo({
     url: '../../my/myhealthdata/myhealthdata',
   })
  },
  fitnessGuidance:function(){
    wx.navigateTo({
      url: '../../my/fitnessguidance/fitnessguidance',
    })
  },
  Customerservice:function(){
    wx.navigateTo({
      url: '../../my/customerservice/customerservice',
    })
  },
  Version:function(){
    wx.navigateTo({
      url: '../../my/version/version',
    })
  }
})