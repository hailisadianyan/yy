//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
   token:''
  },
  //事件处理函数

  onLoad:function(){
    var that=this;
    // wx.getStorage({
    //   key: 'token',
    //   success: function (res) {
    //     console.log(res.data)
    //     if (res.data!= "") {
    //       wx.switchTab({
    //         url: '../fitness/fitnesshomepage/fitnesshomepage',
    //       })
    //     } else {

    //       wx.navigateTo({
    //         url: '../loginregister/login/login',
    //       })
    //     }
    //   }
    // })
  
    setTimeout(function(){
      wx.redirectTo({
        url: '../loginregister/login/login',
      })
    },1000)
 
 },

   

})
