// pages/running/addrunningtrails/addrunningtrails.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    trailsname: "去设置",
    distance: 0,
    broadcastpackets: "去设置"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   
    var that = this;
    console.log(app.globalData.addRunning)
    if (app.globalData.addRunning.name!=undefined){
      that.setData({
        trailsname: app.globalData.addRunning.name,
      })
    }
    if (app.globalData.addRunning.distance!= undefined) {
      that.setData({
        distance: app.globalData.addRunning.distance + '米',
      })
    }
    if (app.globalData.addRunning.num != undefined) {
      that.setData({
        broadcastpackets: app.globalData.addRunning.num + '个'
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   this.onLoad();

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  setRunningtrailsname: function () {
    wx.navigateTo({
      url: '../../running/setrunningtrailsname/setrunningtrailsname',
    })
  },
  setFitnesscenterLocation: function () {
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterlocation/setfitnesscenterlocation',
    })
  },
  setBroadcastpackets: function () {
    wx.navigateTo({
      url: '../../running/setbroadcastpackets/setbroadcastpackets',
    })
  },
  addRunningtrails: function () {
    console.log(app.globalData.addRunning.name)
    console.log(app.globalData.broadcastPackets)
    if (app.globalData.addRunning.name == undefined || app.globalData.broadcastPackets.length==0){
      wx.showToast({
        title: '名称和广播包不能为空',
        icon:'none',
      })
    }else{
    wx.request({ //获取步道
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/authorize/addNewTrail', //接口地址

      data: {  //参数为json格式数据
        broadcastPackets:app.globalData.broadcastPackets,
        tname:app.globalData.addRunning.name
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log( res.data)
        if(res.data.code==1000){
        wx.navigateBack({
          delta:1
        })
        app.globalData.addRunning=[]
        app.globalData.Running = []
        app.globalData.broadcastPackets= []
      }

      if(res.data.code==3002){
        wx.showToast({
          title: res.data.message,
          icon:'none'
        })
      }
      }
      
    })
    }
 
    // wx.navigateTo({
    //   url: '../../running/runningtrails/runningtrails',
    // })
  }
})