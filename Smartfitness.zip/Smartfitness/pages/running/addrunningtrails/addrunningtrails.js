// pages/running/addrunningtrails/addrunningtrails.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    trailsname: "去设置",
    distance: 0,
    broadcastpackets: "去设置"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    var that = this;
    if (options.name != undefined) {
      that.setData({
        trailsname: options.name
      })
    }
    if (options.location != undefined) {
      that.setData({
        distance: options.location
      })
    }
    if (options.count != undefined) {
      that.setData({
        broadcastpackets: options.count+'个'
      })
    }


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  setRunningtrailsname: function () {
    wx.navigateTo({
      url: '../../running/setrunningtrailsname/setrunningtrailsname',
    })
  },
  setFitnesscenterLocation: function () {
    wx.navigateTo({
      url: '../../fitness/setfitnesscenterlocation/setfitnesscenterlocation',
    })
  },
  setBroadcastpackets: function () {
    wx.navigateTo({
      url: '../../running/setbroadcastpackets/setbroadcastpackets',
    })
  },
  addRunningtrails: function () {
    wx.navigateTo({
      url: '../../running/runningtrails/runningtrails',
    })
  }
})