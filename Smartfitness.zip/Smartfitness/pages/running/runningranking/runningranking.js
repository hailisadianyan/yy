// pages/running/runningranking/runningranking.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    defaultImg: '../../image/leftbar_info.png',
    results: [],
    myresult: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var rankdata = [];
    var mydata = [];
    wx.request({ //获取当前排名
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getUserRankings', //接口地址
      data: {  //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        var length = res.data.data.length - 1;
        var Img=''
        var Imgs="";
        for (var i = 0; i < res.data.data.length - 1; i++) {
          if (res.data.data[i].uimg != null) {
            Img = res.data.data[i].uimg.slice(0, 4) == 'http' ? res.data.data[i].uimg : app.globalData.Url + '/image' + res.data.data[i].uimg
          } else {
            Img = app.globalData.Url + '/image' + res.data.data[i].uimg
          }

          if (res.data.data[length].uimg != null) {
            Imgs = res.data.data[length].uimg.slice(0, 5) == 'https' ? res.data.data[length].uimg : app.globalData.Url + '/image' + res.data.data[length].uimg
          } else {
            Imgs = app.globalData.Url + '/image' + res.data.data[length].uimg
          }
          rankdata.push({ //获取所有人的排名
            ranking: i + 1,
            headportrait: Img,
            name: res.data.data[i].unickname,
            distance: res.data.data[i].distance
          })
        }
        mydata.push({//获取当前用户排名，即获取数据的最后一条
          rank: res.data.data[length].rank,
          headportrait: Imgs,
          name: res.data.data[length].unickname,
          distance: res.data.data[i].distance/1
        })
        that.setData({
          results: rankdata,
          myresult: mydata
        })
        console.log(that.data.results, that.data.myresult)
      }
    })
 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  errorFunction: function (e) { //当获取的图片无法加载时，加载默认图片
    // console.log(e)
    var errorImgIndex = e.target.dataset.index //获取循环的下标
    var imgObject = "results[" + errorImgIndex + "].headportrait" //guidance为数据源，对象数组
    var errorImg = {}
    errorImg[imgObject] = this.data.defaultImg //我们构建一个对象
    this.setData(errorImg) //修改数据源对应的数据

  }
  
})