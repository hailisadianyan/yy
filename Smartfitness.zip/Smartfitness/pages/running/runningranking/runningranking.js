// pages/running/runningranking/runningranking.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    personalname: '闪电侠',
    results: [
      {
        ranking: 1,
        headportrait: '../../image/1.jpg',
        name: '阿斯钢',
        exercisetime: 10.12
      },
      {
        ranking: 2,
        headportrait: '../../image/2.jpg',
        name: '啊发生',
        exercisetime: 9.89
      },
      {
        ranking: 3,
        headportrait: '../../image/3.jpg',
        name: '回家',
        exercisetime: 9.12
      },
      {
        ranking: 4,
        headportrait: '../../image/1.jpg',
        name: '花果山单行',
        exercisetime: 8.56
      },
      {
        ranking: 5,
        headportrait: '../../image/2.jpg',
        name: '郭莎莎',
        exercisetime: 8.12
      },
      {
        ranking: 6,
        headportrait: '../../image/3.jpg',
        name: '复健科',
        exercisetime: 7.94
      },
      {
        ranking: 7,
        headportrait: '../../image/1.jpg',
        name: '闪电侠',
        exercisetime: 6.10
      },
      {
        ranking: 8,
        headportrait: '../../image/1.jpg',
        name: '扫地杆',
        exercisetime: 3.21
      },
      {
        ranking: 9,
        headportrait: '../../image/1.jpg',
        name: '按时',
        exercisetime: 1.02
      },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

 
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
   
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
   getWeek:function(i) {
    var now = new Date();
    var firstDay = new Date(now - (now.getDay() - 1) * 86400000);
    firstDay.setDate(firstDay.getDate() + i);
    var mon = Number(firstDay.getMonth()) + 1;
    return mon + "/" + firstDay.getDate();
  },
  
})