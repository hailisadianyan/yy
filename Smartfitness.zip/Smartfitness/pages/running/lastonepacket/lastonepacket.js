// pages/running/lastonepacket/lastonepacket.js


Page({

  /**
   * 页面的初始数据
   */
  data: {
    Array: [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]],
    Index: [0, 0],
    distance:5
   
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
   var Index=e.detail.value;
   var ten = this.data.Array[0][Index[0]];
   var bits = this.data.Array[1][Index[1]];
      console.log(ten);
      console.log(bits);
      if(ten==0){
        this.setData({
          distance:bits
        })
      }else{
        this.setData({
          distance:ten*10+bits
        })
      }
  },
  lastonepacket:function(){
    var distance=this.data.distance
    wx.navigateTo({
      url: '../../running/addbroadcastpackets/addbroadcastpackets?distance='+distance,
    })
  }
})