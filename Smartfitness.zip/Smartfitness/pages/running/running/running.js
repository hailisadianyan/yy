// pages/running/running/running.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
   distance:'',
   content:'',
   lat: '',
   log: '',
   rundistance:'0.00',
   status:0,
   markers: [
     {
       iconPath: "../../image/broadcast_packets.png",
       latitude: 22.554628,
       longitude: 113.887173,
       width: 40,
       height: 40,

       },
     {
       iconPath: "../../image/broadcast_packets.png",
       latitude: 22.549741,
       longitude: 113.885071,
       width: 40,
       height: 40,
    
     },
     {
       iconPath: "../../image/broadcast_packets.png",
       latitude: 22.554773,
       longitude: 113.880373,
       width: 40,
       height: 40,
  
     },
       ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    console.log(options);
    if(options.content!=undefined){
       that.setData({
         distance:options.distance,
         content:options.content
       })
    }
   
    // wx.getLocation({
    //   type: "gcj02",
    //   altitude: true,
    //   success: function (res) {
    //     console.log(res)
    //     that.setData({
    //       lat: res.latitude,
    //       log: res.longitude
    //     })
    //     that.data.markers.push({
    //       //  iconPath: "../../image/fitness_center_1.png",
    //       latitude: res.latitude,
    //       longitude: res.longitude,
    //       width: 50,
    //       height: 50
    //     })
    //   },
    // })

    // that.setData({
    //   markers: this.data.markers
    // })

    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        that.setData({
          lat:res.latitude,
          log:res.longitude,
        })
        wx.request({ //获取步道
          url: app.globalData.Url + '/OutdoorFitness/app/user/running/getTrails', //接口地址

          data: {  //参数为json格式数据
            clatitude: res.latitude,
            clongitude: res.longitude,
            tname:that.data.content
          },
          header: {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'token': wx.getStorageSync('token')
          },
          method: 'POST',
          success: function (res) {
            var trailsname = [];
            console.log('running',res.data)
            for (var i = 0; i < res.data.data[0].broadcastPackets.length; i++) {
              trailsname.push({
                iconPath: "../../image/broadcast_packets.png",
                latitude: res.data.data[0].broadcastPackets[i].tbplatitude,
                longitude: res.data.data[0].broadcastPackets[i].tbplongitude,
                width: 40,
                height: 40,
              })
            }
            that.setData({
              markers: trailsname
            })
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Runningstart:function(){
    var that=this;
    wx.showModal({
      title: '蓝牙未打开',
      content: '前往设置中心开启蓝牙',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          that.setData({
            status:1
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
Runningend:function(){
  var that = this;
  wx.showModal({
    title: '确认结束本次跑步？',
    content:'',
    confirmText:'结束',
    success: function (res) {
      if (res.confirm) {
        console.log('用户点击确定')
        that.setData({
          status: 0
        })
      } else if (res.cancel) {
        console.log('用户点击取消')
      }
    }
  })
}
})