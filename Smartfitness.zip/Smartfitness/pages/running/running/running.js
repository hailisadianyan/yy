// pages/running/running/running.js
var app=getApp();
var util = require('../../../utils/util.js');
var interval = ''; //刷新微信运动数据的定时器，在Runningstart函数中
var a = 0;
var second=0;//时间计数
var runinterval = ''//获取跑步距离的定时器，在getBuletooth函数中
var startinterval = ''//计数的定时器，在Runningstart函数中
var K=1.036;
var c=0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
   distance:'',
   content:'',
   lat: '',
   log: '',
   rundistance:'0.00',
   stepcount:0,
   duration:'00:00:00',
   consume:0,
   speed:0.00,
   status:'',
   markers: [//步道包数据
//      {
//        iconPath: "../../image/broadcast_packets.png",
//        latitude: 22.554628,
//        longitude: 113.887173,
//        width: 40,
//        height: 40,
// },
       ],
       sosphonenum:'',
       weight:'',
       ble:[],//蓝牙数据
       b :0,
       idTrail:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
     wx.showLoading({
       title: '加载中...',
     })
    that.setData({
      status:app.globalData.status
    })
    if(options.content!=undefined){
       that.setData({
         distance:options.distance,
         content:options.content
       })
    }
    that.getSoSNumber();//获取sosphone手机号
    that.getTrails();//获取步道包
    // 
    setTimeout(function () {
      wx.hideLoading()
    }, 1500)
    // setInterval(function(){
    //   wx.getBluetoothAdapterState({
    //     success: function (res) {
    //       console.log('获取蓝牙状态的变化',res)
    //     }
    //   },2000)
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that=this;
    that.wechatlogin();// 每十秒获取一次微信运动数据
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
 
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
   console.log('页面隐藏')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    var that=this;
    console.log('页面卸载',app.globalData.status)
    if(app.globalData.status==1){
    wx.showModal({
      title: '结束跑步',
      content: '确定结束本次跑步？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          clearInterval(interval);
          that.setData({
            status:0
          })
          app.globalData.status = 0;
        } else if (res.cancel) {
          console.log('用户点击取消')
          app.globalData.status = 1;
        }
      }
    })
    }
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  Runningstart:function(){
    var that=this;
    wx.getBluetoothAdapterState({ //获取蓝牙状态
      success: function (res) {
        console.log('getBluetoothAdapterState:', res)
        if (res.available == false) {
          wx.showModal({
            title: '蓝牙未打开',
            content: '前往设置中心开启蓝牙',
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击确定')
                that.setData({
                  status: 0
                })
               
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        } else if (res.available == true){
          //  that.setData({
          //   status:1
          //  })
          app.globalData.status = 1;
        }
      },
    })

    
           
    that.openBluetoothAdapter()//蓝牙搜索

    that.getTimeTwo();
    interval = setInterval(that.onReady, 10000); //每十秒获取一次微信运动数据
    // console.log(that.data.show)
  

   
  },
Runningend:function(){
  var that = this;
 
  wx.showModal({
    title: '结束跑步',
    content:'确认结束本次跑步？',
    confirmText:'结束',
    success: function (res) {
      if (res.confirm) {
        console.log('用户点击确定')
        clearInterval(interval);
        clearInterval(runinterval)
        clearInterval(startinterval)
        wx.closeBluetoothAdapter({
          success: function (res) {
            if (that.data.rundistance!=0){
            that.addRunningRecord();
            
            } else if (that.data.rundistance == 0){
             wx.showToast({
               title: '跑步距离为零不做记录上传',
               icon:'none'
             })
            }
            console.log('全部结束', res)
            a=0;
            second=0;
            that.setData({
              rundistance:'0.00',
              stepcount: 0,
              duration: '00:00:00',
              consume: 0,
              speed: 0.00,
            })
          }
        })
        that.setData({
          status: 0
        })
        app.globalData.status = 0;
      } else if (res.cancel) {
        console.log('用户点击取消')
      }
    }
  })
 
},
  helpSOS:function(){ //打电话
    console.log(this.data.sosphonenum)
    wx.makePhoneCall({
      phoneNumber: this.data.sosphonenum 
    })
  },
  getSoSNumber:function(){
    var that=this;
    wx.request({ //获取SOSNumber
      url: app.globalData.Url + '/OutdoorFitness/app/user/getAppUserData', //接口地址

      data: {  //参数为json格式数据
      
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
       
        console.log('getSoSNumber',res.data)
        that.setData({
          sosphonenum: res.data.data.usosPhone,
          weight: res.data.data.uweight
        })
      }
    })
  },
  getTrails:function(){
    var that=this;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        that.setData({
          lat: res.latitude,
          log: res.longitude,
        })
        wx.request({ //获取步道
          url: app.globalData.Url + '/OutdoorFitness/app/user/running/getTrails', //接口地址

          data: {  //参数为json格式数据
            clatitude: res.latitude,
            clongitude: res.longitude,
            tname: that.data.content
          },
          header: {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'token': wx.getStorageSync('token')
          },
          method: 'POST',
          success: function (res) {
            var trailsname = [];
            console.log('running', res.data)
            for (var i = 0; i < res.data.data[0].broadcastPackets.length; i++) {
              trailsname.push({
                iconPath: "../../image/broadcast_packets.png",
                latitude: res.data.data[0].broadcastPackets[i].tbplatitude,
                longitude: res.data.data[0].broadcastPackets[i].tbplongitude,
                distance: res.data.data[0].broadcastPackets[i].tbpdistance,
                width: 40,
                height: 40,
                mac: res.data.data[0].broadcastPackets[i].tbpmac
              })
            }
            that.setData({
              markers: trailsname,
              idTrail:res.data.data[0].idTrail
            })
            markers: trailsname
            console.log(that.data.markers)
          }
        })
      }
    })
  },
  openBluetoothAdapter: function () {
    var that = this;
    wx.openBluetoothAdapter({ //打开蓝牙适配
      success: function (res) {
        console.log('初始化蓝牙适配器成功');
        // that.setData({
        //   status: 1
        // })
        that.startBlue();
      },
      complete: function () {
        wx.getBluetoothAdapterState({ //获取蓝牙状态
          success: function (res) {
            console.log('getBluetoothAdapterState:', res)
            if (res.available == false) {
              wx.showToast({
                title: '蓝牙未适配成功，请先打开蓝牙',
                icon: 'none',
                duration: 3000
              })
              wx.onBluetoothAdapterStateChange(function (res) { //蓝牙状态改变
                console.log('监听蓝牙打开：', res.available)
                if (res.available) {
                  setTimeout(function () {
                    that.startBlue();
                  }, 2000)
                 
                }
              })
            }
          },
        })
      }
    })
  },
  startBlue: function () {
   
    var that = this;
    console.log('weight', that.data.weight)
    wx.startBluetoothDevicesDiscovery({  //开始搜寻附近的蓝牙外围设备
     services: ['00000001-1212-EFDE-1523-785FEABCD123'],
       allowDuplicatesKey:true,
       interval:1000,
      success: function (res) {
        
        console.log('startBluetoothDevicesDiscovery', res)
    
        that.onBluetooth(function(c){
          console.log('callback',c)
          wx.hideLoading()
          second++
          var time = util.SecondToDate(second)
          var myconsume = '';
          var speed = '';
          if (that.data.weight != null) {
            myconsume = (a * that.data.weight * K / 1000).toFixed(2)
          } else if (that.data.weight == null) {
            myconsume = (a * 60 * K / 1000).toFixed(2)
          }
          speed = (a * 60 / (second * 1000)).toFixed(2)
          that.setData({
            rundistance: a,
            consume: myconsume,
            speed: speed,
            duration: time
          })  
         });
       
      },
    
      
    })

  },
 


  onBluetooth: function (callback) {
    var that = this;
    wx.showLoading({
      title: '搜索中',
    })
  wx.onBluetoothDeviceFound(function (res) {
      // wx.hideLoading()
      c=1;
    if (res.devices[0].RSSI > -80) {
      console.log('扫描新设备：', res)
     that.setData({
          status: 1
        })
      if (res.devices.length > 1) {
       
        app.globalData.deviceId=res.devices[0].deviceId;

        for (var j = 0; j < res.devices.length; j++) {
          if (app.globalData.deviceId==res.devices[j].deviceId){
             console.log('无输出')
          } else if (app.globalData.deviceId != res.devices[j].deviceId){

              for (var i = 0; i < that.data.markers.length; i++) {
         
                if (that.data.markers[i].mac == res.devices[j].deviceId) {

              // console.log(that.data.markers[i].distance)
                 a += that.data.markers[i].distance;
                console.log('a', a)
              }
            }
          }
        }
      }  
      }
         callback(c);
      
    })
    setTimeout(
      function(){
         if(c==0){
           wx.hideLoading();
           wx.showModal({
            title: '开始跑步',
            content: '当前没有扫描到广播包，是否开始跑步？',
            success: function (res) {
            if (res.confirm) {
            console.log('用户点击确定')
            startinterval = setInterval(function () {
              second++
              var time = util.SecondToDate(second)
              that.setData({
                duration: time
              })
            }, 1000)
            that.setData({
              status: 1
            })
            app.globalData.status = 1;
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
         }
      },5000
    )
    
  },

  wechatlogin: function () {
    var that = this;
   
    wx.login({
      success: function (res) {
        // console.log(res)
        var code = res.code;

        if (res.code) {
          wx.request({
            url: 'https://api.weixin.qq.com/sns/jscode2session',
            data: {
              appid: app.globalData.APPID,
              secret: app.globalData.SECRET,
              js_code: code,
              grant_type: 'authorization_code'
            },
            header: {
              'content-type': 'application/json'
            },
            success: function (res) {
              // console.log(res)
              var openid = res.data.openid //返回openid
              var sessionkey = res.data.session_key
              app.globalData.openid = openid
              app.globalData.sessionkey = sessionkey
              wx.getWeRunData({
                success(res) {
                  // console.log(res)
                  that.setData({
                    encryptedData: res.encryptedData,
                    iv: res.iv
                  })
                
                  that.getTime(res.encryptedData, res.iv)
                }
              })
            }

          })

        }

      }
    })
  },
  getTime: function (a, b) {
    var that = this;
    var encryptedData = a;
    var iv = b;

    wx.request({ //获取SOSNumber
      url: app.globalData.Url + '/OutdoorFitness/wx/WxController/wxDecrypt', //接口地址

      data: {  //参数为json格式数据
        appId: app.globalData.APPID,
        sessionKey: app.globalData.sessionkey,
        encryptedData: encryptedData,
        iv: iv
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log(res)
        console.log(res.data.data.stepInfoList[30])
        var step = res.data.data.stepInfoList[30].step - that.data.countstep
        // that.setData({
        //   stepcount: step
        // })
        if (isNaN(step)) {
          that.setData({
            stepcount: 0
          })
        } else {
          that.setData({
            stepcount: step / 1
          })
        }
      }
    })
  },
  getTimeTwo: function () { 
    var that = this;
    var encryptedData = that.data.encryptedData;
    var iv = that.data.iv;

    wx.request({ //
      url: app.globalData.Url + '/OutdoorFitness/wx/WxController/wxDecrypt', //接口地址

      data: {  //参数为json格式数据
        appId: app.globalData.APPID,
        sessionKey: app.globalData.sessionkey,
        encryptedData: encryptedData,
        iv: iv
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log(res)
        // console.log(res.data.data.stepInfoList[30].step)
        that.setData({
          countstep: res.data.data.stepInfoList[30].step
        })
      }
    })
  },
  addRunningRecord:function(){
    var that=this;
    console.log(that.data.idTrail);
    wx.request({ //
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/addRunningRecord', //接口地址
      data: {  //参数为json格式数据
        reconsume: that.data.consume,
        redistance: (that.data.rundistance/1000).toFixed(2),
        reduration: second,
        respeed: that.data.speed,
        restepNumber:that.data.stepcount,
        tid:that.data.idTrail
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res)
        if(res.statusCode==200){
        wx.showToast({
          title: '上传跑步记录成功',
          icon: 'none'
        })
        }
      }
    })
  }
})