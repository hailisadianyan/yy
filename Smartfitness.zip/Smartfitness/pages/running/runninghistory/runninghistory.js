// pages/running/runninghistory/runninghistory.js
var app = getApp()
// var wxCharts = require('../../../libs/wxcharts.js'); // 引入wx-charts.js文件\
var columnChart = null;
var columnChartweek = null;
var columnChartmonth = null;
var chartData = {
  day: {
    // title: '总成交量',
    data: [15, 20, 45, 37, 55, 102, 12],
    categories: ['1/22', '1/23', '1/24', '1/25', '1/26', '1/27', '1/28']
  },
  week: {
    data: [420, 435, 430, 468, 408],
    categories: ['12/25-12/31', '1/1-1/7', '1/8-1/14', '1/15-1/21', '1/22-1/28']
  },
  month: {
    data: [1090, 1142, 1186, 1252, 1374],
    categories: ['1月', '2月', '3月', '4月', '5月']
  }
};
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    day: {
      date: {
        month: 1,
        day: 27
      },
      km: 10.12,
      num: 2,
      consume:626,
      stepcount: 15000,
      duration:'01:20:05',
      speed:0.16,
    },
    week: {
      date: {
        startdate: '1/1',
        enddate: '1/7'
      },
      km: 79.12,
      num: 8,
      consume: 626,
      stepcount: 15000,
      duration: '01:20:05',
      speed: 0.16,
    },
    month: {
      date: {
        year: 2018,
        month: 1
      },
      minute: '33.20',
      num: 60,
      consume: 4261,
    },

    dayconsume: [1204, 1304, 1344, 1634, 1244],
    dayexercisetime: ['08:30', '10:30', "15:30", "18:00", "20:00"],
    dayheight: [],
    daycalories: [],

    weekconsume: [1204, 1304, 1344, 1634, 1244, 1500, 1800],
    weekexercisetime: ['星期一', '星期二', "星期三", "星期四", "星期五", "星期六", "星期日"],
    weekheight: [],
    weekcalories: [],

    monthconsume: [1204, 1304, 1344, 1634, 1244, 1734, 1324, 1424, 1244, 1534, 1324, 1364, 1454, 1454, 1844, 1124, 1024, 1024, 1824, 1424, 1324, 1324, 1024],
    monthexercisetime: [],
    monthheight: [],
    monthcalories: [], 

    fitness: [
      {
        km: 4,//健身器材名
        starttime: '21:57',//开始时间
        stepcount:7000,
        exercisetime: '00:35:13',//锻炼时长
        speed: "08'08",
        exerciseconsumption: '140', //锻炼消耗
      },
      {
        km:6.12,//健身器材名
        times: 1, //健身次数
        starttime: '8:30',//开始时间
        stepcount: 8000,
        exercisetime: '00:45:13',//锻炼时长
        speed: "10'58",
        exerciseconsumption: '460', //锻炼消耗
      },
      
    ],



    fitnesshistory: [
      {
        date: {
          month: 1,
          day: 17
        },
        historydata: [
          {
            km: 4,//跑步距离
            starttime: '21:57',//开始时间
            stepcount: 7000,
            exercisetime: '00:35:13',//锻炼时长
            speed: "08'08",
            exerciseconsumption: '140', //锻炼消耗
          },
          {
            km: 6,//跑步距离
            starttime: '10:37',//开始时间
            stepcount: 7000,
            exercisetime: '00:55:13',//锻炼时长
            speed: "10'08",
            exerciseconsumption: '340', //锻炼消耗
          }
        ]
      },
      {
        date: {
          month: 1,
          day: 16
        },
        historydata: [
          {
            km: 3,//跑步距离
            starttime: '8:37',//开始时间
            stepcount: 7000,
            exercisetime: '00:25:13',//锻炼时长
            speed: "10'08",
            exerciseconsumption: '120', //锻炼消耗
          },
          {
            km: 4.56,//跑步距离
            starttime: '7:57',//开始时间
            stepcount: 12400,
            exercisetime: '01:21:13',//锻炼时长
            speed: "07'08",
            exerciseconsumption: '432', //锻炼消耗
          }
        ]
      },
    ],

    height: '',
    hartTitle: '总成交量',
    isMainChartDisplay: true,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {



    var that = this;
    var historylength = this.data.fitnesshistory.length;
    var historydatalength = this.data.fitnesshistory[0].historydata.length;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res);
        // 可使用窗口宽度、高度
      
        // 计算主体部分高度,单位为px
        that.setData({
          height: res.windowHeight + 180 * (historylength * historydatalength)
        })
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (e) {
    var that = this;
    that.day();
    that.week();
    that.month();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  swiperTab: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },

  //点击切换
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }

  },
  day: function () {
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.dayconsume.length; i++) {
      b.push(Math.ceil(((this.data.dayconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      dayheight: b
    })
    console.log(this.data.dayheight)
    for (var i = 0; i < this.data.dayexercisetime.length; i++) {

      var histogram = {};
      for (var j = 0; j < this.data.dayheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.dayheight[j];
          histogram.date = this.data.dayexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      daycalories: calories
    })
  },
  week: function () {
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.weekconsume.length; i++) {
      b.push(Math.ceil(((this.data.weekconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      weekheight: b
    })
    console.log(this.data.weekheight)
    for (var i = 0; i < this.data.weekexercisetime.length; i++) {

      var histogram = {};
      for (var j = 0; j < this.data.weekheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.weekheight[j];
          histogram.date = this.data.weekexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      weekcalories: calories
    })
  },
  month: function () {
    var myDate = new Date();
    var month = myDate.getMonth() + 1  //获取当前月份(0-11,0代表1月，所以要加1);
    var day = myDate.getDate();//获取当前日（1-31）
    if (month < 10) {
      month = "0" + month;
    }
    var arr1 = [];
    for (var i = 1; i <= day; i++) {
      if (i >= 0 && i <= 9) {
        i = "0" + i;
      }
      arr1.push(month + "/" + i);
    }
    this.setData({
      monthexercisetime: arr1
    })
    console.log(this.data.monthexercisetime);
    var b = [];
    for (var i = 0; i < this.data.monthconsume.length; i++) {
      b.push(Math.ceil(((this.data.monthconsume[i] / 1000).toFixed(2) * 100)))
    }
    this.setData({
      monthheight: b
    })


    var calories = []

    for (var i = 0; i < this.data.monthexercisetime.length; i++) {

      var histogram = {};
      for (var j = 0; j < this.data.monthheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.monthheight[j];
          histogram.date = this.data.monthexercisetime[i];
          calories.push(histogram);
        }
      }
    }
    console.log(calories);
    this.setData({
      monthcalories: calories
    })
  }
})