// pages/running/runninghistory/runninghistory.js
var app = getApp()
var util = require('../../../utils/util.js'); 

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    daydatemonth:'',
    daydateday:'',
    daykm:'',
    daynum:'',
    dayconsumes:'',
    daystepcount:'',
    dayduration:'',
    dayspeed:'',
    dayruning:[],
    reduration:[],
    daymax:'',
    dayrecreatetime: [],
    dayheight: [],
    daycalories: [],

    weekfrist: '',
    weekend:'',
    weeknum: '',
    weekkm: '',
    weekduration:'',
    weekconsumes: '',
    weekspeed:'',
    weekstepcount:'',
    weektime: ['星期一', '星期二', "星期三", "星期四", "星期五", "星期六", "星期日"],
    week:[],
    weekmax:'',
    weekfitnesshistory:[],
    weekheight: [],
    weekcalories: [],

     year: '',
    month: '',
    monthnum: '',
    monthkm: '',
    monthduration: '',
    monthconsumes: '',
    monthspeed: '',
    monthstepcount: '',
     monthmax: '',
    fitnesshistory: [],
    monthexercisetime: [],
    monthheight: [],
    monthcalories: [], 

    height: '',
    hartTitle: '总成交量',
    isMainChartDisplay: true,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {



    var that = this;
 
 
    that.dayTimes();
    that.weekTimes();
    that.monthTimes();
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function (e) {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  swiperTab: function (e) {
    var that = this;
    that.setData({ currentTab: e.detail.current });
  },

  //点击切换
  swichNav: function (e) {
    var that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  day: function () {
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.reduration.length; i++) {
      b.push(Math.ceil(((this.data.reduration[i] / this.data.daymax).toFixed(2) * 100)))
    }
    this.setData({
      dayheight: b
    })
    // console.log(this.data.dayheight)
    for (var i = 0; i < this.data.dayrecreatetime.length; i++) {

      var histogram = {};
      for (var j = 0; j < this.data.dayheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.dayheight[j];
          histogram.date = this.data.dayrecreatetime[i];
          calories.push(histogram);
        }
      }
    }
    // console.log(calories);
    this.setData({
      daycalories: calories
    })
  },
  week: function () {
    var calories = []
    var b = [];
    for (var i = 0; i < this.data.week.length; i++) {
      b.push(Math.ceil(((this.data.week[i].time / this.data.weekmax).toFixed(2) * 100)))
    }
    this.setData({
      weekheight: b
    })
    // console.log('this.data.week', this.data.week)
    // console.log(this.data.weekheight)
    for (var i = 0; i < this.data.week.length; i++) {

      var histogram = {};
      for (var j = 0; j < this.data.weekheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.weekheight[j];
          histogram.date = this.data.week[i].name;
          histogram.value = this.data.week[i].value;
          calories.push(histogram);
        }
      }
    }
    // console.log(calories);
    this.setData({
      weekcalories: calories
    })
  },
  month: function () {
    var b = [];
    for (var i = 0; i < this.data.monthexercisetime.length; i++) {
      b.push(Math.ceil(((this.data.monthexercisetime[i].time / this.data.monthmax).toFixed(2) * 100)))
    }
    this.setData({
      monthheight: b
    })

    var calories = []
    for (var i = 0; i < this.data.monthexercisetime.length; i++) {
      var histogram = {};
      for (var j = 0; j < this.data.monthheight.length; j++) {
        if (i == j) {
          histogram.num = this.data.monthheight[j];
          histogram.date = this.data.monthexercisetime[i].name;
          calories.push(histogram);
        }
      }
    }
    this.setData({
      monthcalories: calories
    })
  },
  dayTimes:function(){
    var that=this;
    var time = util.formatTime(new Date());
    var month = time.split(' ')[0].split('/')[1]
    var day = time.split(' ')[0].split('/')[2]

    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManTimes', //接口地址

      data: {  //参数为json格式数据
        dayType: 1,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log('daydataall:',res.data)
        var reduration = util.SecondToDate(res.data.data.reduration)
        that.setData({
          daydatemonth: month,
          daydateday: day,
          daynum: res.data.data.times / 1,
          daykm: res.data.data.redistance / 1,
          dayduration: reduration/1,
          dayconsumes: res.data.data.reconsume / 1,
          dayspeed: res.data.data.respeed / 1,
          daystepcount: res.data.data.restepNumber / 1,
        })
      }
    })

    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManRecords', //接口地址

      data: {  //参数为json格式数据
        dayType: 1,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        var dayRunning = [];
        for (var i = res.data.data.length - 1; i >= 0; i--) {
          that.data.dayrecreatetime.push(util.formatTimeThree(res.data.data[i].recreatetime)) //获取一天每次跑步的开始时间
          that.data.reduration.push(res.data.data[i].reduration)//获取一天每次跑步的持续时间
          dayRunning.push({
            recreatetime: util.formatTimeTwo(res.data.data[i].recreatetime),
            reconsume: res.data.data[i].reconsume,
            redistance: res.data.data[i].redistance,
            starttime: util.formatTimeThree(res.data.data[i].recreatetime),
            reduration: util.SecondToDate(res.data.data[i].reduration),
            respeed: res.data.data[i].respeed,
            restepNumber: res.data.data[i].restepNumber
          })
        }
      
        var max = util.Max(that.data.reduration);
        that.setData({
          daymax: max,
          dayrunning: dayRunning
        })
        that.day();
      }
    })

  },

  weekTimes:function(){
    var that = this;
    var time = util.formatTime(new Date());
    var weekfrist = util.Week(0).split('-')[1] + '/'+util.Week(0).split('-')[2]
    var weekend = util.Week(6).split('-')[1] + '/' + util.Week(6).split('-')[2]
    var week = []
    for (var i = 0; i < 7; i++) { //获取一周的日期
      week.push({
        value: util.Week(i), //week.value 一周的日期 2018-08-01
        name: that.data.weektime[i]  //week.name 星期一到星期天
      })
    }
    that.setData({
      week: week
    })
    // console.log(weekfrist, weekend)
    // console.log('输出week:',week)
    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManTimes', //接口地址

      data: {  //参数为json格式数据
        dayType: 2,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
       
        //  console.log('weekdataall:',res.data)
        if (res.data.data.reduration==null){
          res.data.data.reduration =0
        }
        var reduration = util.SecondToDate(res.data.data.reduration)
        that.setData({
          weekfrist: weekfrist,
          weekend: weekend,
          weeknum: res.data.data.times / 1,
          weekkm: res.data.data.redistance / 1,
          weekduration: reduration,
          weekconsumes: res.data.data.reconsume / 1,
          weekspeed: res.data.data.respeed / 1,
          weekstepcount: res.data.data.restepNumber / 1,
        })
      }
    })

    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManRecords', //接口地址

      data: {  //参数为json格式数据
        dayType: 2,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log('获取一周跑步的详细信息：',res.data)
        var weekRunnig = [];
        var weekRunningdata = [];
        var Runningdata = [];
       
         for(var i=0;i<res.data.data.length;i++){
           weekRunnig.push({ //存放每周的跑步数据
             recreatetime: util.formatTimeTwo(res.data.data[i].recreatetime),
             reconsume: res.data.data[i].reconsume,
             redistance: res.data.data[i].redistance,
             starttime: util.formatTimeThree(res.data.data[i].recreatetime),
             reduration: util.SecondToDate(res.data.data[i].reduration),
             respeed: res.data.data[i].respeed,
             restepNumber: res.data.data[i].restepNumber
          })
           weekRunningdata.push({ //将一周每天的日期和跑步时长单独拿出来存放到weekRunningdate里
             recreatetime: util.formatTimeTwo(res.data.data[i].recreatetime),
             reduration: res.data.data[i].reduration,
           })
         }
        // console.log('输出weekRunnig：', weekRunnig)
        // console.log('输出 weekRunningdata：', weekRunningdata)


        var data = util.RunningScreenDate(weekRunnig) //筛选数据，将同一天的数据放在一个数组中
        for (var k in data) {
          // console.log('输出data[k]:', data[k]);
          Runningdata.push({
            historydata: data[k],
            weekdate: data[k][0].recreatetime.split('-')
          })
        }
        // console.log('输出Runningdata:', Runningdata)  
        var a = util.runningtrans(weekRunningdata) //数组把相同key 值合并，value相加
        var timemax = [] //获取week[i].time的最大值
        // console.log('输出a',a)
        for (var i = 0; i < week.length; i++) { //将一周有时长的数据，放入week里
          for (var j = 0; j < a.length; j++) {
            if (week[i].value == a[j].recreatetime) {
              week[i].time = a[j].reduration
              timemax.push(week[i].time)
            }
          }
        }
        var weekmax = util.Max(timemax);//获取时长的最大值
         that.setData({
          weekfitnesshistory: Runningdata,
          week: week,
          weekmax: weekmax
        })
        // console.log('输出that.data.weekfitnesshistory', that.data.weekfitnesshistory)
        that.week(); //调用上面的week（）,画出柱状图 
      }
    })
   },
  monthTimes: function () {
    var that = this;
    var time = util.formatTime(new Date());
    var year = time.split(' ')[0].split('/')[0];//获取当前年份
    var month = time.split(' ')[0].split('/')[1]; //获取当前月份
    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManTimes', //接口地址

      data: {  //参数为json格式数据
        dayType: 3,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log('monthdataall:', res.data)
        if (res.data.data.reduration == null) {
          res.data.data.reduration = 0
        }
        var reduration = util.SecondToDate(res.data.data.reduration)
        that.setData({
          month: month,
          year: year,
          monthnum: res.data.data.times / 1,
          monthkm: res.data.data.redistance / 1,
          monthduration: reduration,
          monthconsumes: res.data.data.reconsume / 1,
          monthspeed: res.data.data.respeed / 1,
          monthstepcount: res.data.data.restepNumber / 1,
        })
      }
    })


    var montharr = []
    var myDate = new Date();
    var year = myDate.getFullYear();
    var month = myDate.getMonth() + 1  //获取当前月份(0-11,0代表1月，所以要加1);
    var day = myDate.getDate();//获取当前日（1-31）
    if (month < 10) {
      month = "0" + month;
    }
    var arr1 = [];
    var arr2 = [];
    for (var i = 1; i <= day; i++) {
      if (i < 10) {
        i = "0" + i;
      }
      arr1.push(month + "/" + i);
      arr2.push(year + '-' + month + '-' + i)

    }
    for (var i = 0; i < arr1.length; i++) {
      montharr.push({
        value: arr2[i],
        name: arr1[i]
      })
    }
    // console.log('arr', arr1.length, arr2, montharr)
    this.setData({
      monthexercisetime: montharr
    })

    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManRecords', //接口地址

      data: {  //参数为json格式数据
        dayType: 3,
        recreatetime: time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        // console.log('获取一月跑步的详细信息：', res.data)
        var monthRunnig = [];
        var monthRunningdata = [];
        var Runningdata = [];

        for (var i = 0; i < res.data.data.length; i++) {
          monthRunnig.push({ //存放每月的跑步数据
            recreatetime: util.formatTimeTwo(res.data.data[i].recreatetime),
            reconsume: res.data.data[i].reconsume,
            redistance: res.data.data[i].redistance,
            starttime: util.formatTimeThree(res.data.data[i].recreatetime),
            reduration: util.SecondToDate(res.data.data[i].reduration),
            respeed: res.data.data[i].respeed,
            restepNumber: res.data.data[i].restepNumber
          })
          monthRunningdata.push({ //将一月每天的日期和跑步时长单独拿出来存放到weekRunningdate里
            recreatetime: util.formatTimeTwo(res.data.data[i].recreatetime),
            reduration: res.data.data[i].reduration,
          })
        }
        // console.log('输出monthRunnig：', monthRunnig)
        // console.log('输出monthRunningdata：', monthRunningdata)


        var data = util.RunningScreenDate(monthRunnig) //筛选数据，将同一天的数据放在一个数组中
        for (var k in data) {
          // console.log('输出data[k]:', data[k]);
          Runningdata.push({
            historydata: data[k],
            monthdate: data[k][0].recreatetime.split('-')
          })
        }
        // console.log('输出Runningdata:', Runningdata)

        var a = util.runningtrans(monthRunningdata) //数组把相同key 值合并，value相加
       
        var timemax = [] //获取month[i].time的最大值
        var monthexercisetime = that.data.monthexercisetime
        for (var i = 0; i < monthexercisetime.length; i++) { //将一月有时长的数据，放入week里
          for (var j = 0; j < a.length; j++) {
            if (monthexercisetime[i].value == a[j].recreatetime) {
              monthexercisetime[i].time = a[j].reduration
              timemax.push(monthexercisetime[i].time)
            }
          }
        }
        var monthmax = util.Max(timemax);//获取时长的最大值

        that.setData({
          fitnesshistory: Runningdata,
          monthexercisetime: monthexercisetime,
          monthmax: monthmax,
          length: monthRunnig.length
        })
        // console.log('输出that.data.monthfitnesshistory', that.data.fitnesshistory)
        that.month();
        that.getHeight();
      }
    })
  },
  getHeight:function(){
    var that=this;
    // console.log('输出length:', that.data.length)
    wx.getSystemInfo({
      success: function (res) {
        // console.log(res);
        // 可使用窗口宽度、高度

        // 计算主体部分高度,单位为px
        that.setData({
          height: res.windowHeight + 200 * that.data.length
        })
      }
    })
 }
  })