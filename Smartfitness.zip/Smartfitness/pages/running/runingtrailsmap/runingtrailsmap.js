// pages/running/runingtrailsmap/runingtrailsmap.js
// var QQMapWX = require('../../../libs/qqmap-wx-jssdk.js');
// var qqmapsdk;
var app=getApp();
Page({
  data: {
    lat: '',
    log: '',
    height: '',
    markers: [
    //   {
    //   iconPath: "../../image/fitness_center_1.png",
    //   latitude: 22.554628,
    //   longitude: 113.887173,
    //   width: 50,
    //   height: 50,
    //   callout: {
    //     content: '01步道 5公里',
    //     fontSize: 12,
    //     color: '#ffffff',
    //     bgColor: '#000000',
    //     padding: 5,
    //     borderRadius: 10,
    //     boxShadow: '4px 8px 16px 0 rgba(0)',
    //     display: 'ALWAYS'
    //   }
    // }, 
  
    ]

  },
  onLoad: function (options) {
    var that = this;


    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        that.setData({
          lat:res.latitude,
          log:res.longitude
        })

        wx.request({ //获取步道
          url: app.globalData.Url + '/OutdoorFitness/app/user/running/getTrails', //接口地址

          data: {  //参数为json格式数据
            clatitude: res.latitude,
            clongitude: res.longitude,
          },
          header: {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'token': wx.getStorageSync('token')
          },
          method: 'POST',
          success: function (res) {
            var trailsname = [];
            console.log(res.data)
            for (var i = 0; i < res.data.data.length; i++) {
              trailsname.push({
                iconPath: "../../image/fitness_center_1.png",
                latitude: res.data.data[i].broadcastPackets[0].tbplatitude,
                longitude: res.data.data[i].broadcastPackets[0].tbplongitude,
                width: 50,
                height: 50,
                callout: {
                  content: res.data.data[i].tname + ' ' + res.data.data[i].broadcastPackets[0].distance+'公里',
                    fontSize: 12,
                    color: '#ffffff',
                    bgColor: '#000000',
                    padding: 5,
                    borderRadius: 10,
                    boxShadow: '4px 8px 16px 0 rgba(0)',
                  display: 'BYCLICK'
                 }
              })
            }
            that.setData({
              markers: trailsname
            })
          }
        })
      }
    })

    wx.getSystemInfo({
      success: function (res) {
        console.log(res);
        // 可使用窗口宽度、高度
        console.log('height=' + res.windowHeight);
        console.log('width=' + res.windowWidth);
        // 计算主体部分高度,单位为px
        that.setData({
          height: res.windowHeight + 'px'
        })
      }
    })

  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    console.log(e.markerId)
  },
  controltap(e) {
    console.log(e.controlId)
  },
  fitnesscenter: function () {
   wx.navigateBack({
     delta:1
   })
  },
  SearchInput: function (e) {
    var that = this;
    var name = e.detail.value;
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        console.log(res)
        that.setData({
          lat: res.latitude,
          log: res.longitude
        })

        wx.request({ //获取步道
          url: app.globalData.Url + '/OutdoorFitness/app/user/running/getTrails', //接口地址

          data: {  //参数为json格式数据
            clatitude: res.latitude,
            clongitude: res.longitude,
            tname:name
          },
          header: {
            'content-type': 'application/json',
            'Accept': 'application/json',
            'token': wx.getStorageSync('token')
          },
          method: 'POST',
          success: function (res) {
            var trailsname = [];
            console.log(res.data)
            for (var i = 0; i < res.data.data.length; i++) {
              trailsname.push({
                iconPath: "../../image/fitness_center_1.png",
                latitude: res.data.data[i].broadcastPackets[0].tbplatitude,
                longitude: res.data.data[i].broadcastPackets[0].tbplongitude,
                width: 50,
                height: 50,
                callout: {
                  content: res.data.data[i].tname + ' ' + res.data.data[i].broadcastPackets[0].distance + '公里',
                  fontSize: 12,
                  color: '#ffffff',
                  bgColor: '#000000',
                  padding: 5,
                  borderRadius: 10,
                  boxShadow: '4px 8px 16px 0 rgba(0)',
                  display: 'BYCLICK'
                }
              })
            }
            that.setData({
              markers: trailsname
            })
          }
        })
      }
    })
  },
})