// pages/running/setbroadcastpackets/setbroadcastpackets.js
var recordStartX = 0;
var currentOffsetX = 0;
var app=getApp();
Page({


  /**
   * 页面的初始数据
   */
  data: {
    details: {},
    isAuthorize:'',
    arr: [],
    startX: 0, //开始坐标
    startY: 0,
    editIndex: 0,
    delBtnWidth: 150,//删除按钮宽度单位（rpx）
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      isAuthorize: wx.getStorageSync('isAuthorize')
    })
    if (app.globalData.broadcastPackets.length!=0){
      var broadcastPackets=[]
      
      for (var i = 0; i < app.globalData.broadcastPackets.length;i++){
      broadcastPackets.push({
        tbpmac: app.globalData.broadcastPackets[i].tbpmac,
        tbpaddress: app.globalData.broadcastPackets[i].tbpaddress,
        src: '../../image/list_in.png',
        isTouchMove: false
      })
      }
      this.setData({
        arr: broadcastPackets
      })
    }
    console.log(this.data.arr)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  addBroadcastpacket: function () {
    app.globalData.Running=[];
    wx.scanCode({
      success: (res) => {
        console.log(res)
        app.globalData.Running.id=res.result
        wx.navigateTo({
          url: '../../running/addbroadcastpackets/addbroadcastpackets',
        })
      }
    })
  },

  confirm:function(){
    console.log('获取app.globalData.broadcastPackets：', app.globalData.broadcastPackets)
    var length='';
    var distance=0;
    console.log(app.globalData.broadcastPackets.length)
    console.log(app.globalData.broadcastPackets[0].tbpdistance)
    for (var i = 0; i < app.globalData.broadcastPackets.length; i++) {
    
  distance+=(+app.globalData.broadcastPackets[i].tbpdistance )
     
    }
    app.globalData.addRunning.num = app.globalData.broadcastPackets.length;
    app.globalData.addRunning.distance = distance;
  wx.navigateBack({
    delta: 1,
  })
  
  },
  touchstart: function (e) {
    //开始触摸时 重置所有删除
    this.data.arr.forEach(function (v, i) {
      if (v.isTouchMove)//只操作为true的
        v.isTouchMove = false;
    })
    this.setData({
      startX: e.changedTouches[0].clientX,
      startY: e.changedTouches[0].clientY,
      arr: this.data.arr
    })
  },
  //滑动事件处理
  touchmove: function (e) {
    var that = this,
      index = e.currentTarget.dataset.index,//当前索引
      startX = that.data.startX,//开始X坐标
      startY = that.data.startY,//开始Y坐标
      touchMoveX = e.changedTouches[0].clientX,//滑动变化坐标
      touchMoveY = e.changedTouches[0].clientY,//滑动变化坐标
      //获取滑动角度
      angle = that.angle({ X: startX, Y: startY }, { X: touchMoveX, Y: touchMoveY });
    that.data.arr.forEach(function (v, i) {
      v.isTouchMove = false
      //滑动超过30度角 return
      if (Math.abs(angle) > 30) return;
      if (i == index) {
        if (touchMoveX > startX) //右滑
          v.isTouchMove = false
        else //左滑
          v.isTouchMove = true
      }
    })
    //更新数据
    that.setData({
      arr: that.data.arr
    })
  },
  /**
   * 计算滑动角度
   * @param {Object} start 起点坐标
   * @param {Object} end 终点坐标
   */
  angle: function (start, end) {
    var _X = end.X - start.X,
      _Y = end.Y - start.Y
    //返回角度 /Math.atan()返回数字的反正切值
    return 360 * Math.atan(_Y / _X) / (2 * Math.PI);
  },
  //删除事件
  del: function (e) {
    var that=this;
    var index = e.currentTarget.dataset.index

    wx.showModal({
      title: '确定删除该广播包',
      success: function (res) {
        if (res.confirm) {
          that.data.arr.splice(index, 1)
          app.globalData.broadcastPackets.splice(index,1)
          that.setData({
            arr: that.data.arr
          })
        
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }
})