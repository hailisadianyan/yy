// pages/running/setbroadcastpackets/setbroadcastpackets.js
Page({


  /**
   * 页面的初始数据
   */
  data: {
    details: {},
    arr: [{ //arr:[{},{}]
      equipment: {
        id: '3B:30:8D:90',
        local: '广东省深圳市桃花源创新科技园第一分园'
      }
    },
    {
      equipment: {
        id: '5B:40:9F:99',
        local: '广东省深圳市桃花源创新科技园第二分园'
      }
    },
    {
      equipment: {
        id: '42:40:C6:39',
        local: '广东省深圳市桃花源创新科技园第三分园'
      }
    },
    {
      equipment: {
        id: '9F:3D:9F:4C',
        local: '广东省深圳市桃花源创新科技园第一分园'
      }
    },
    {
      equipment: {
        id: '2A:40:8E:7B',
        local: '广东省深圳市桃花源创新科技园第二分园'
      }
    }
    ]

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    console.log(123123);

    console.log(this.data.arr[0])
    console.log(options)
    if (options.id != undefined) {
      this.setData({
        equipmentcontent: options
      })
    }
    console.log(this.data.equipmentcontent)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  addBroadcastpacket: function () {
    var id = "3B:30:8D:90"
   
    wx.scanCode({
      success: (res) => {
        console.log(res)
        wx.navigateTo({
          url: '../../running/addbroadcastpackets/addbroadcastpackets?id=' + id,
        })
      }
    })
  },
  Equimentcontent: function (e) {
    var portindex = e.currentTarget.dataset.id;
    var arr = this.data.arr;
    var Id = arr[portindex].equipment.id
    
    wx.navigateTo({
      url: '../../running/addbroadcastpackets/addbroadcastpackets?id=' + Id
    })
  },
  confirm:function(){
    var count=this.data.arr.length;
    wx.navigateTo({
      url: '../../running/addrunningtrails/addrunningtrails?count='+count,
    })
  }
})