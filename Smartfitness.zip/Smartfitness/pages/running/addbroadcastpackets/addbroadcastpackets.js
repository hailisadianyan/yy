// pages/running/addbroadcastpackets/addbroadcastpackets.js
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
   id:'',
   location:'去设置',
   distance:'去设置'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    console.log(app.globalData.Running)
      if(app.globalData.Running.id!=undefined){
        that.setData({
          id:app.globalData.Running.id
        })
      }
    if (app.globalData.Running.location != undefined) {
      that.setData({
        location: app.globalData.Running.location
      })
    }
    if (app.globalData.Running.distance != undefined) {
      that.setData({
        distance: app.globalData.Running.distance+'米'
      })
    }


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.onLoad();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  chooseLocation:function(){
    var that=this;
    wx.chooseLocation({
      success: function(res) {
        // var lat=res.latitude;
        // var log=res.longitude;
        console.log(res);
        app.globalData.Running.location=res.name
        app.globalData.Running.latitude = res.latitude
        app.globalData.Running.longitude =res.longitude
        that.onLoad();
      },
    })
  },
  Lastone:function(){
    wx.navigateTo({
      url: '../../running/lastonepacket/lastonepacket',
    })
  },
  addBroadcastpacket:function(){
    var that=this;
    console.log('获得app.globalData.broadcastPackets',app.globalData.broadcastPackets)
    var title =that.broadcastPackets(app.globalData.broadcastPackets, app.globalData.Running.id)
    if (title != false) {
      app.globalData.broadcastPackets.push({
        tbpaddress: app.globalData.Running.location,
        tbpdistance: app.globalData.Running.distance,
        tbplatitude: app.globalData.Running.latitude,
        tbplongitude: app.globalData.Running.longitude,
        tbpmac: app.globalData.Running.id
      })
     wx.navigateBack({
       delta:1
     })
    }
    if (title==false){
      wx.showToast({
        title: '请不要重复添加广播包',
        icon:'none',
        duration:2000,
      
      })
      that.a();
    }
   
   
  },
  broadcastPackets:function(arr,id){
    if (arr.length != 0) {
      for (var i = 0; i < arr.length; i++) {
        if (arr[i].tbpmac == id) {
          return false;
        }
      }
    } else {

      return true;
    }
  },
  a:function(){
    setTimeout(function () {
      wx.navigateBack({
        delta: 1,
      })
    }, 1500)
  }
})