// pages/running/runninghomepage/runninghomepage.js
var app=getApp();
var util = require('../../../utils/util.js'); 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num:'',
    distance:'',
    stepcount:'',
    duration:'',
    calories:'',
    speed:'',
  },
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var time = util.formatTime(new Date());
    var that=this;
    wx.request({ //获取跑步总数据
      url: app.globalData.Url + '/OutdoorFitness/app/user/running/getRunningManTimes', //接口地址

      data: {  //参数为json格式数据
        dayType:4,
        recreatetime:time
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json',
        'token': wx.getStorageSync('token')
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
         that.setData({
           num:res.data.data.times/1,
           distance: res.data.data.redistance/1,
           duration: Math.ceil(res.data.data.reduration/60),
           calories: res.data.data.reconsume/1,
           speed: res.data.data.respeed/1,
           stepcount: res.data.data.restepNumber/1,
         })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  Runningtrails: function () {
    wx.navigateTo({
      url: '../../running/runningtrails/runningtrails',
    })
  },
  Runninghistory: function () {
    wx.navigateTo({
      url: '../../running/runninghistory/runninghistory',
    })
  },
  Runningranking: function () {
    wx.navigateTo({
      url: '../../running/runningranking/runningranking',
    })
  },
 
})