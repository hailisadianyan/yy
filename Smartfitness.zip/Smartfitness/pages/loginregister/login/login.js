// pages/loginregister/login/login.js
var app=getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {

    uphone: "",
    upasswd: "",
    firstlogin:0,
  },
  onLoad: function (options) {
    var that=this;
    wx.getStorage({
      key: 'firstlogin',
      success: function (res) {
        // console.log(res.data)
        that.setData({
          firstlogin:res.data
        })
      }
    })
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res.data)
        if(res.data){
          wx.switchTab({
            url: '../../fitness/fitnesshomepage/fitnesshomepage',
          })
        }
      }
    })
  },

  getPhonenum: function (e) { //获取输入的账号信息
    this.setData({
      uphone: e.detail.value
    })
  },
  getPassword: function (e) {//获取输入的密码信息
    this.setData({
      upasswd: e.detail.value
    })
  },
  Login: function (e) { //发送登录请求
  var that=this;
       wx.request({ //登录
         url: app.globalData.Url +'/OutdoorFitness/app/user/doUserLogin', //接口地址
      data: {  
        uphone:this.data.uphone,
        upwd:this.data.upasswd        //参数为json格式数据
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json'
      },
      method:'POST',
      success: function (res) {
        // console.log(res.data)
        var phone=that.data.uphone;
       var firstlogin=that.data.firstlogin;

        if(res.data.code==1000){
          wx.showToast({
            title: '登录成功',
            icon: 'success',
            duration: 2000
          })
          if(firstlogin==0){ //设置firstlogin判断是否是第一次登录
          wx.navigateTo({
            url: '../../loginregister/perfectinformation/perfectinformation?phone='+phone,
          })
          } else if (firstlogin == 1){
            wx.switchTab({
              url: '../../fitness/fitnesshomepage/fitnesshomepage',
            })
          }
          wx.setStorage({
            key: "token",
            data: res.data.data
          })
          wx.setStorage({
            key: "isAuthorize",
            data: res.data.isAuthorize
          })
          wx.setStorage({
            key: "firstlogin",
            data: 1
          })
        }else if(res.data.code==1001){
          wx.showToast({
            title: '登录失败',
            icon: 'none',
            duration: 2000
          })
        }
      },
      fail:function(res){
        console.log('连接失败')
        wx.showToast({
          title: '连接服务器失败，请重试',
          icon:'none'
        })
      }
    })
  },
  goRegister: function (e) { //去注册界面
    wx.navigateTo({
      url: '../../loginregister/register/register',

    })
  },
  retrievepassword: function () { //去重置密码界面
    wx.navigateTo({
      url: '../../loginregister/retrievepassword/retrievepassword',
    })
  },

  thirdlogin:function(){
     wx.navigateTo({
       url: '../../loginregister/thirdlogin/thirdlogin',
     })


   
  }
})