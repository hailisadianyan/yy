// pages/loginregister/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

    uphone: "",
    upasswd: ""
  },
  getPhonenum: function (e) { //获取输入的账号信息
    this.setData({
      uphone: e.detail.value
    })
  },
  getPassword: function (e) {//获取输入的密码信息
    this.setData({
      upasswd: e.detail.value
    })
  },
  Login: function (e) { //发送登录请求

    // wx.request({
    //   url: "/OutdoorFitness/app/user/doUserLogin",
    //   data: {
    //    uphone:this.data.uphone,
    //    upwd:this.data.upasswd
    //   },
    //   method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    //   header: {
    //     'content-type': 'application/json'
    //   }, // 设置请求的 header
    //   success: function (res) {
    //     // success

    //     console.log('服务器返回' + res);

    //   },
    //   fail: function () {
    //     // fail
    //     // wx.hideToast();
    //   },
    //   complete: function () {
    //     // complete
    //   }
    // })
    wx.navigateTo({
      url: '../../loginregister/perfectinformation/perfectinformation',
    })
    wx.setStorage({
      key: "token",
      data: "123124123214"
    })
  },
  goRegister: function (e) { //去注册界面
    wx.navigateTo({
      url: '../../loginregister/register/register',

    })
  },
  retrievepassword: function () { //去重置密码界面
    wx.navigateTo({
      url: '../../loginregister/retrievepassword/retrievepassword',
    })
  },
  
})