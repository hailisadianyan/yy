// pages/loginregister/perfectinformation/perfectinformation.js
var app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone:'',
    nickname:'',
    sexyvalue:'',
    brithday:'',
    height:'',
    weight:'',
    sosphone:'',
    items:[
      {src:'../../image/boy.png',value:'男'},
     { src: '../../image/girl.png', value: '女'}
   ],
   token:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
     console.log(options);
     that.setData({
       phone:options.phone
     })
    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log(res.data)
        that.setData({
          token:res.data
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  getNickname:function(e){ //获取昵称
   this.setData({
     nickname:e.detail.value
   })
  },
  getBirthday:function(e){
  this.setData({
 birthday:e.detail.value
  })
  },
  getHeight: function (e) { //获取身高
    this.setData({
      height: e.detail.value
    })
  },
  getWeight: function (e) { //获取体重
    this.setData({
     weight: e.detail.value
    })
  },
  sosPhone:function(e){
   this.setData({
     sosphone:e.detail.value
   })
  },
  changechoose:function(e){ //获取性别
  
     if(e.target.dataset.id==0){
       this.data.items[0].src = '../../image/boy_ed.png';
       this.data.items[0].value = "男";
       this.data.items[1].src = '../../image/girl.png';
       this.data.items[1].value = "女";
         this.setData({
           sexyvalue:this.data.items[0].value,
           items:this.data.items
         })
     } else if (e.target.dataset.id == 1){
       this.data.items[0].src = '../../image/boy.png';
       this.data.items[0].value = "男";
       this.data.items[1].src = '../../image/girl_ed.png';
       this.data.items[1].value = "女";
       this.setData({
         sexyvalue:this.data.items[1].value,
         items:this.data.items
       })
     }
   console.log(this.data.sexyvalue)
  },
  Perfectinfo:function(e){ //完善个人信息
    console.log(this.data.phone)
    console.log(this.data.birthday)
    console.log(this.data.sexyvalue)
    console.log(this.data.height)
    console.log(this.data.nickname)
  
    console.log(this.data.sosphone)
    console.log(this.data.weight)
     wx.request({
       url: app.globalData.Url + "/OutdoorFitness/app/user/doUpdateUserDatas",
      data: {
          uage:'',
          uphone: this.data.phone,
          unickname: this.data.nickname,
          ugender: this.data.sexyvalue,
          ubirthday: this.data.birthday,
          uheight:this.data.height,
          uweight:this.data.weight,
          usosPhone: this.data.sosphone,
      },
      method: 'POST', 
      header: { // 设置请求的 header
        'content-type': 'application/json',
        'Accept': 'application/json',
         'token':this.data.token
      },
      success: function (res) {
       

       console.log(res.data)
        if(res.data.code==1000){
          wx.showToast({
            title: '完善成功',
            icon: 'none',
            duration: 2000
          })
           wx.switchTab({
           url: '../../fitness/fitnesshomepage/fitnesshomepage',
           })
        }else if(res.data.code==1001){
          wx.showToast({
            title: '完善失败',
            icon: 'none',
            duration: 2000
          }) 
        }
        

      },
      fail: function () {
        // fail
        // wx.hideToast();
      },
      complete: function () {
        // complete
      }
    })
 
  }
})