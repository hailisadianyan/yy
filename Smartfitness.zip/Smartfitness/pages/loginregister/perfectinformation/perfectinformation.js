// pages/loginregister/perfectinformation/perfectinformation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    nickname:'',
    sexyvalue:'',
    brithday:'',
    height:'',
    weight:'',
    items:[
      {src:'../../image/boy.png',value:'男'},
     { src: '../../image/girl.png', value: '女'}
   ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  getNickname:function(e){ //获取昵称
   this.setData({
     nickname:e.detail.value
   })
  },
  getHeight: function (e) { //获取身高
    this.setData({
      height: e.detail.value
    })
  },
  getWeight: function (e) { //获取体重
    this.setData({
      height: e.detail.value
    })
  },
  changechoose:function(e){ //获取性别
  
     if(e.target.dataset.id==0){
       this.data.items[0].src = '../../image/boy_ed.png';
       this.data.items[0].value = "男";
       this.data.items[1].src = '../../image/girl.png';
       this.data.items[1].value = "女";
         this.setData({
           sexyvalue:this.data.items[0].value,
           items:this.data.items
         })
     } else if (e.target.dataset.id == 1){
       this.data.items[0].src = '../../image/boy.png';
       this.data.items[0].value = "男";
       this.data.items[1].src = '../../image/girl_ed.png';
       this.data.items[1].value = "女";
       this.setData({
         sexyvalue:this.data.items[1].value,
         items:this.data.items
       })
     }
   console.log(this.data.sexyvalue)
  },
  Perfectinfo:function(e){

     // wx.request({
    //   url: "/OutdoorFitness/app/user/doUserLogin",
    //   data: {
          // uage:''
          // ubirthday:this.data.birthday
          // ugender: this.data.sexyvalue
          // uheight:this.data.height
          // unickname:this.data.nickname
          // uphone:''
          // usosPhone:''
          // uweight:this.data.weight
    //   }
    //   method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    //   header: {
    //     'content-type': 'application/json'
    //   }, // 设置请求的 header
    //   success: function (res) {
    //     // success

    //     console.log('服务器返回' + res);

    //   },
    //   fail: function () {
    //     // fail
    //     // wx.hideToast();
    //   },
    //   complete: function () {
    //     // complete
    //   }
    // })
   wx.switchTab({
     url: '../../fitness/fitnesshomepage/fitnesshomepage',
   })
  }
})