// pages/loginregister/register/register.js
var interval = null //倒计时函数
var app=getApp()
Page({
  data: {
    uphone: "",//手机号
    code: "",//验证码
    upwd: '',//密码
    confirmpassword:'',
    disabled: true,
    fun_id: 2,
    time: '获取验证码', //倒计时 
    currentTime: 61
  },
  onLoad:function(options){
    console.log(app.globalData.Url)
  },
  getPhonenum: function (e) { //获取输入的手机号
    this.setData({
      uphone:e.detail.value
    })
     
    if (this.data.uphone.length==11) {
      this.setData({
        disabled: false,
        time: '发送验证码'
      })
    }
  },
  getCodeValue:function(e){ //获取输入的验证码
    this.setData({
      code:e.detail.value
    })
   
  },
  getPassword:function(e){ //获取输入的密码
    this.setData({
      upwd: e.detail.value
    })
  
  },
  getConfirmPassword: function (e) {//获取输入的密码
    this.setData({
      confirmpassword: e.detail.value
    })
   
  },


  getCode: function (phone) { //获取验证码函数
    var that = this;
    var currentTime = that.data.currentTime
    wx.request({ //获取验证码
      url: app.globalData.Url + '/OutdoorFitness/app/user/doSendUserCode', //接口地址
      data: {          //参数为json格式数据
        phone: phone,
        type: 1
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json'
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data)
        if(res.data.code==1000){
          wx.showToast({
            title: '发送成功，请注意查收',
            icon: 'none',
            duration: 2000
          })
        } else if (res.data.code == 1001) {
          wx.showToast({
            title: '发送失败',
            icon: 'none',
            duration: 2000
          })
        }
       
      }
    })

    interval = setInterval(function () {
      currentTime--;
      that.setData({
        time: currentTime + '秒后重新发送'
      })
      if (currentTime <= 0) {
        clearInterval(interval)
        that.setData({
          time: '重新发送',
          currentTime: 61,
          disabled: false
        })
      }
    }, 100)
  },
  getVerificationCode() {
    console.log()
    var that = this
    var uphone=that.data.uphone
    this.getCode(uphone); //调用获取验证码函数
   
    that.setData({
      disabled: true
    })
  },
  confirmRegister: function () {

    
  
    if (this.data.upwd == this.data.confirmpassword) {
      if (this.data.upwd.length >= 6) {
        wx.request({
          url: app.globalData.Url + "/OutdoorFitness/app/user/doUserResetPwd",
          data: {
            uphone: this.data.uphone,
            upwd: this.data.upwd,
            code: this.data.code
          },
          method: 'POST',
          header: {// 设置请求的 header
            'content-type': 'application/json',
            'Accept': 'application/json'
          },
          success: function (res) {
            // success

            console.log(res.data);
            if (res.data.code == 1000) {
              wx.showToast({
                title: '重置成功',
                icon: 'success',
                duration: 2000
              })
              wx.navigateTo({
                url: '../../loginregister/login/login',
              })
            }else if(res.data.code==1001){
              wx.showToast({
                title: '验证码不匹配或者已经过期',
                icon: 'none',
                duration: 2000
              })
            }
          },
          fail: function () {
            // fail
            // wx.hideToast();
          },
          complete: function () {
            // complete
          }
        })

      } else {
        wx.showToast({
          title: '密码不可少于6位',
          icon: 'none',
          duration: 2000
        })
      }
    } else {
      wx.showToast({
        title: '两次密码输入不一样',
        icon: 'none',
        duration: 2000
      })
    }

  }
})