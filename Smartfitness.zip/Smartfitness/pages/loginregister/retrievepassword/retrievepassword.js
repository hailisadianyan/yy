// pages/loginregister/register/register.js
var interval = null //倒计时函数
Page({
  data: {
    uphone: "",//手机号
    code: "",//验证码
    upwd: '',//密码
    confirmpassword:'',
    disabled: true,
    fun_id: 2,
    time: '获取验证码', //倒计时 
    currentTime: 61
  },

  getPhonenum: function (e) { //获取输入的手机号
    this.setData({
      uphone:e.detail.value
    })
     
    if (this.data.uphone.length==11) {
      this.setData({
        disabled: false,
        time: '发送验证码'
      })
    }
  },
  getCodeValue:function(e){ //获取输入的验证码
    this.setData({
      code:e.detail.value
    })
   
  },
  getPassword:function(e){ //获取输入的密码
    this.setData({
      upwd: e.detail.value
    })
  
  },
  getConfirmPassword: function (e) {//获取输入的密码
    this.setData({
      confirmpassword: e.detail.value
    })
   
  },


  getCode: function (options) { //获取验证码函数
    var that = this;
    var currentTime = that.data.currentTime
      // wx.request({
    //   url: "/OutdoorFitness/app/user/doUserLogin",
    //   data: {
    //    phone:this.data.uphone,
    //    type:1
    //   },
    //   method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    //   header: {
    //     'content-type': 'application/json'
    //   }, // 设置请求的 header
    //   success: function (res) {
    //     // success

    //     console.log('服务器返回' + res);

    //   },
    //   fail: function () {
    //     // fail
    //     // wx.hideToast();
    //   },
    //   complete: function () {
    //     // complete
    //   }
    // })

    interval = setInterval(function () {
      currentTime--;
      that.setData({
        time: currentTime + '秒后重新发送'
      })
      if (currentTime <= 0) {
        clearInterval(interval)
        that.setData({
          time: '重新发送',
          currentTime: 61,
          disabled: false
        })
      }
    }, 100)
  },
  getVerificationCode() {
    console.log()
    this.getCode(); //调用获取验证码函数
    var that = this
    that.setData({
      disabled: true
    })
  },
  confirmRegister: function () {

    
  

    if (this.data.upwd == this.data.confirmpassword) {
      if (this.data.upwd.length >= 6) {
        // wx.request({
        //   url: "/OutdoorFitness/app/user/doUserLogin",
        //   data: {
        //    uphone:this.data.uphone,
        //    upwd:this.data.upasswd
        //    code:this.data.code
        //   },
        //   method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
        //   header: {
        //     'content-type': 'application/json'
        //   }, // 设置请求的 header
        //   success: function (res) {
        //     // success

        //     console.log('服务器返回' + res);

        //   },
        //   fail: function () {
        //     // fail
        //     // wx.hideToast();
        //   },
        //   complete: function () {
        //     // complete
        //   }
        // })
        wx.showToast({
          title: '已重置密码',
          icon: 'success',
          duration: 2000
        })
      } else {
        wx.showToast({
          title: '密码不可少于6位',
          icon: 'none',
          duration: 2000
        })
      }
    } else {
      wx.showToast({
        title: '两次密码输入不一样',
        icon: 'none',
        duration: 2000
      })
    }
  }
})