// pages/loginregister/register/register.js
var interval = null //倒计时函数
var app = getApp()
Page({
  data: {
    uphone:"",//手机号
    code:"",//验证码
    upwd:'',//密码
    confirmpassword:'',
    disabled:true,
    fun_id: 2,
    time: '获取验证码', //倒计时 
    currentTime: 61
  },

  getPhonenum:function(e){ //获取输入的手机号码
    this.setData({
    uphone:e.detail.value
    })
    var length= this.data.uphone.length;
    if (length==11){ //如果账号为11位，可以发送验证码
     this.setData({
       disabled:false,
       time:'发送验证码'
     })
   }
  },
  getCodeValue:function(e){ //获取输入的验证码
    this.setData({
      code:e.detail.value
    })
 
  },
    getPassword: function (e) {//获取输入的密码
    this.setData({
      upwd: e.detail.value
    })
    
  },
    getConfirmPassword: function (e) {//获取再次输入的密码
    this.setData({
      confirmpassword: e.detail.value
    })
   
  },


  getCode: function (phone) {
    var that = this;
    var currentTime = that.data.currentTime
     console.log(phone)
        wx.request({ //获取验证码
          url: app.globalData.Url+'/OutdoorFitness/app/user/doSendUserCode', //接口地址
      data: {          //参数为json格式数据
       phone:phone,
        type:0  
      },
      header: {
        'content-type': 'application/json',
        'Accept': 'application/json'
      },
      method:'POST',
      success: function (res) {
        console.log(res.data)
        if(res.data.code==1000){
          wx.showToast({
            title: '注册成功',
            icon: 'success',
            duration: 2000
          })
          wx.navigateTo({
            url: '../../loginregister/login/login',
          })
        }
         else if(res.data.code==1001){
           wx.showModal({
             title: '注册',
             content: '该手机号已被注册',
           })
        }
      }
    })



    interval = setInterval(function () {
      currentTime--;
      that.setData({
        time: currentTime + '秒后重新发送'
      })
      if (currentTime <= 0) {
        clearInterval(interval)
        that.setData({
          time: '重新发送',
          currentTime: 61,
          disabled:false
        })
      }
    }, 100)


  },
  getVerificationCode() {
    var that = this
    var uphone = that.data.uphone;
    that.getCode(uphone);
   
    that.setData({
      disabled:true
    })
  },
  confirmRegister:function(){
   
    if (this.data.upwd == this.data.confirmpassword){
      if (this.data.upwd.length>=6){
       wx.request({
         url: app.globalData.Url +"/OutdoorFitness/app/user/doUserRegister",
      data: {
       uphone:this.data.uphone,
       upwd:this.data.upwd,
       code:this.data.code
      },
      method: 'POST', 
      header: {// 设置请求的 header
        'content-type': 'application/json',
         'Accept': 'application/json'
      }, 
      success: function (res) {
        // success

        console.log('服务器返回' + res);
        if(res.data.code==1000){
          wx.showToast({
            title: '注册成功',
            icon: 'success',
            duration: 2000
          })
        }
      },
      fail: function () {
        // fail
        // wx.hideToast();
      },
      complete: function () {
        // complete
      }
    })
    
      }else{
        wx.showToast({
          title: '密码不可少于6位',
          icon: 'none',
          duration: 2000
        })
      }
    }else{
      wx.showToast({
        title:'两次密码输入不一样',
        icon:'none',
        duration: 2000
      })
    }

  }
})